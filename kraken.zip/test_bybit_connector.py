"""
Simple test script for the Bybit V5 connector
"""
import asyncio
import logging
from pybit.unified_trading import HTTP

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class BybitV5Connector:
    """
    Simplified Bybit V5 connector for testing
    """
    
    def __init__(self, api_key=None, api_secret=None, testnet=True):
        """
        Initialize the Bybit V5 connector
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.client = None
        self.initialized = False
    
    async def initialize(self):
        """Initialize the Bybit V5 client"""
        logger.info(f"Initializing Bybit V5 connector (testnet: {self.testnet})")
        self.client = HTTP(
            testnet=self.testnet,
            api_key=self.api_key,
            api_secret=self.api_secret
        )
        self.initialized = True
        return self
    
    def get_server_time(self):
        """Get server time to test connection"""
        if not self.initialized:
            raise RuntimeError("Connector not initialized")
        
        response = self.client.get_server_time()
        logger.info(f"Server time response: {response}")
        return response
    
    def get_market_data(self, symbol="BTCUSDT"):
        """Get market data for a specific symbol"""
        if not self.initialized:
            raise RuntimeError("Connector not initialized")
        
        # Get ticker data
        response = self.client.get_tickers(category="linear", symbol=symbol)
        logger.info(f"Ticker response: {response}")
        return response

async def main():
    """Main function to test the Bybit V5 connector"""
    logger.info("Starting Bybit V5 connector test")
    
    # Initialize connector
    connector = BybitV5Connector(testnet=True)
    await connector.initialize()
    
    # Test server time
    server_time = connector.get_server_time()
    logger.info(f"Server time: {server_time}")
    
    # Test market data
    market_data = connector.get_market_data("BTCUSDT")
    logger.info(f"Market data: {market_data}")
    
    logger.info("Bybit V5 connector test completed")

if __name__ == "__main__":
    asyncio.run(main())
