"""
Bybit exchange connector module.
"""
