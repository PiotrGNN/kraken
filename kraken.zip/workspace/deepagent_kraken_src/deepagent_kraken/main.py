"""
Main entry point for the DeepAgent Kraken trading bot.
"""

import os
import sys
import asyncio
import logging
import signal
import yaml
import time
import random
from logging.handlers import RotatingFileHandler
from typing import Dict, Any, Optional

from fastapi import FastAPI
from prometheus_client import start_http_server

from app.core.env_manager import EnvManager, Environment
from app.core.order_router import OrderRouter
from app.core.scheduler import Scheduler
from app.strategies.trend_follower import TrendFollowerStrategy
from app.risk.atr_risk import ATRRiskManager
from app.utils.metrics import (
    setup_metrics, 
    update_pnl, 
    update_equity, 
    update_open_risk,
    update_exchange_status
)

# Configure logging
def setup_logging(log_level=logging.INFO, log_file="deepagent_kraken.log"):
    """Setup logging configuration."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # Configure root logger
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=[
            # Console handler
            logging.StreamHandler(),
            # Rotating file handler
            RotatingFileHandler(
                os.path.join(log_dir, log_file),
                maxBytes=10 * 1024 * 1024,  # 10 MB
                backupCount=5
            )
        ]
    )
    
    # Set lower log level for some noisy libraries
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    
    return logging.getLogger(__name__)

# Load configuration
def load_config(config_path="config/env.yaml") -> Dict[str, Any]:
    """Load configuration from YAML file."""
    try:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f) or {}
        return config
    except Exception as e:
        print(f"Error loading config: {e}")
        return {}

# Create FastAPI app
app = FastAPI(title="DeepAgent Kraken Trading Bot")

# Setup metrics endpoint
app = setup_metrics(app)

@app.get("/")
async def root():
    return {"message": "DeepAgent Kraken Trading Bot API"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

# Main trading loop
async def trading_loop(
    env_manager: EnvManager,
    order_router: OrderRouter,
    strategy: TrendFollowerStrategy,
    config: Dict[str, Any]
) -> None:
    """
    Main trading loop.
    
    Args:
        env_manager: Environment manager
        order_router: Order router
        strategy: Trading strategy
        config: Bot configuration
    """
    logger = logging.getLogger("trading_loop")
    
    # Trading parameters
    interval = config.get("trading_interval", 60)  # seconds
    max_retries = config.get("max_retries", 5)
    retry_delay = config.get("retry_delay", 10)  # seconds
    
    logger.info(f"Starting trading loop with interval: {interval}s")
    
    # Register signal handlers for graceful shutdown
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, lambda: asyncio.create_task(shutdown(loop)))
    
    # Main loop
    retries = 0
    while True:
        try:
            # Check exchange health
            exchange_health = await order_router.health_check_all_exchanges()
            logger.info(f"Exchange health: {exchange_health}")
            
            # Execute trading strategy
            result = await strategy.execute_strategy()
            logger.info(f"Strategy execution result: {result}")
            
            # Update metrics
            position = await order_router.get_position(strategy.symbol)
            account = await order_router.get_account_balance()
            
            equity = account.get("equity", 0)
            pnl = position.get("unrealized_pnl", 0)
            position_size = abs(position.get("size", 0))
            position_value = position_size * position.get("mark_price", 0)
            
            update_equity(equity)
            update_pnl(pnl)
            update_open_risk(position_value)
            
            # Reset retry counter on success
            retries = 0
            
            # Wait for next iteration
            await asyncio.sleep(interval)
            
        except asyncio.CancelledError:
            logger.info("Trading loop cancelled")
            break
        except Exception as e:
            logger.error(f"Error in trading loop: {e}", exc_info=True)
            
            # Exponential backoff for retries
            retries += 1
            wait_time = retry_delay * (2 ** (retries - 1)) + random.uniform(0, 1)
            wait_time = min(wait_time, 300)  # Cap at 5 minutes
            
            logger.warning(f"Retrying in {wait_time:.2f}s (retry {retries}/{max_retries})")
            
            if retries > max_retries:
                logger.critical(f"Exceeded maximum retries ({max_retries}), exiting")
                return
            
            await asyncio.sleep(wait_time)

async def shutdown(loop):
    """Graceful shutdown."""
    logger = logging.getLogger(__name__)
    logger.info("Shutting down...")
    
    # Cancel all running tasks
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    
    for task in tasks:
        task.cancel()
    
    logger.info(f"Cancelling {len(tasks)} outstanding tasks")
    await asyncio.gather(*tasks, return_exceptions=True)
    
    loop.stop()

@app.on_event("startup")
async def startup_event():
    """Startup event handler."""
    global env_manager, order_router, strategy, scheduler
    
    logger = logging.getLogger(__name__)
    logger.info("Starting DeepAgent Kraken Trading Bot")
    
    try:
        # Load configuration
        config = load_config()
        
        # Initialize environment manager
        env_manager = EnvManager()
        
        # Initialize order router
        order_router = OrderRouter(env_manager)
        
        # Initialize risk manager
        risk_config = config.get("risk", {})
        risk_manager = ATRRiskManager(risk_config)
        
        # Initialize trading strategy
        strategy_config = config.get("strategy", {})
        strategy = TrendFollowerStrategy(order_router, risk_manager, strategy_config)
        
        # Initialize scheduler
        scheduler_config = config.get("scheduler", {})
        scheduler = Scheduler(env_manager, scheduler_config)
        await scheduler.start()
        
        # Start Prometheus metrics server
        try:
            start_http_server(8000)
            logger.info("Prometheus metrics server started on port 8000")
        except Exception as e:
            logger.error(f"Failed to start Prometheus metrics server: {e}")
        
        # Start trading loop
        asyncio.create_task(trading_loop(env_manager, order_router, strategy, config))
        logger.info("Trading bot started")
        
    except Exception as e:
        logger.critical(f"Failed to start trading bot: {e}", exc_info=True)
        sys.exit(1)

@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown event handler."""
    logger = logging.getLogger(__name__)
    logger.info("Shutting down DeepAgent Kraken Trading Bot")
    
    # Stop scheduler
    if 'scheduler' in globals():
        await scheduler.stop()

if __name__ == "__main__":
    # Setup logging
    logger = setup_logging()
    
    # Check if we're running in API mode or standalone mode
    api_mode = os.getenv("API_MODE", "false").lower() == "true"
    
    if api_mode:
        # Run as FastAPI app
        import uvicorn
        logger.info("Starting in API mode")
        uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=False)
    else:
        # Run as standalone bot
        logger.info("Starting in standalone mode")
        
        # Create event loop
        loop = asyncio.get_event_loop()
        
        try:
            # Load configuration
            config = load_config()
            
            # Initialize environment manager
            env_manager = EnvManager()
            
            # Initialize order router
            order_router = OrderRouter(env_manager)
            
            # Initialize risk manager
            risk_config = config.get("risk", {})
            risk_manager = ATRRiskManager(risk_config)
            
            # Initialize trading strategy
            strategy_config = config.get("strategy", {})
            strategy = TrendFollowerStrategy(order_router, risk_manager, strategy_config)
            
            # Initialize scheduler
            scheduler_config = config.get("scheduler", {})
            scheduler = Scheduler(env_manager, scheduler_config)
            
            # Start scheduler
            loop.run_until_complete(scheduler.start())
            
            # Start Prometheus metrics server
            try:
                start_http_server(8000)
                logger.info("Prometheus metrics server started on port 8000")
            except Exception as e:
                logger.error(f"Failed to start Prometheus metrics server: {e}")
            
            # Run trading loop
            loop.run_until_complete(trading_loop(env_manager, order_router, strategy, config))
            
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received, shutting down")
        except Exception as e:
            logger.critical(f"Fatal error: {e}", exc_info=True)
        finally:
            # Clean up
            if 'scheduler' in locals():
                loop.run_until_complete(scheduler.stop())
            
            # Close the loop
            loop.close()
            logger.info("Trading bot stopped")
