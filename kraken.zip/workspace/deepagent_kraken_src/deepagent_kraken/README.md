# DeepAgent Kraken Trading Bot

A robust cryptocurrency trading bot with multi-exchange support, failover capabilities, and advanced risk management.

## Features

- **Multi-Exchange Support**: Primary trading on Bybit V5 API with failover to OKX and Binance
- **Automatic Failover**: Seamlessly switches between exchanges if the primary exchange becomes unavailable
- **Trend-Following Strategy**: SMA-50/SMA-200 crossover with RSI filter
- **Advanced Risk Management**: ATR-based position sizing and dynamic stop-loss placement
- **Environment Switching**: Automatic switching between TESTNET and MAINNET based on schedule
- **Monitoring**: Prometheus and Grafana integration for real-time performance monitoring
- **Secure API Key Management**: API keys stored in Abacus secrets

## Architecture

The bot is built with a modular architecture:

1. **Exchange Connectors**: Standardized interface for interacting with different exchanges
2. **Order Router**: Handles order placement with automatic failover between exchanges
3. **Trading Strategy**: Implements the trend-following strategy with RSI counter
4. **Risk Management**: ATR-based position sizing and stop-loss placement
5. **Environment Manager**: Handles switching between TESTNET and MAINNET
6. **Monitoring**: Prometheus metrics and Grafana dashboards

## Trading Strategy

The bot implements a trend-following strategy with RSI counter:

- **Direction**: SMA-50 / SMA-200 cross determines trend direction
- **Long Entry**: Only when SMA50 > SMA200 and RSI-14 < 65
- **Short Entry**: Only when SMA50 < SMA200 and RSI-14 > 35

## Risk Management

The bot implements a comprehensive risk management system:

1. **Position Sizing**: equity × 1% / (ATR14 × 1.5)
2. **Stop-Loss**: 1.5 × ATR (server-side)
3. **Trailing-Stop**: Move to breakeven after +1 ATR, then trail by 0.5 ATR

## Prerequisites

- Python 3.8+
- Docker and Docker Compose (for monitoring)
- API keys for Bybit, OKX, and Binance

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/deepagent_kraken.git
   cd deepagent_kraken
   ```

2. Create a virtual environment and install dependencies:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Set up API keys as environment variables or in Abacus secrets:
   ```
   export ABACUS_SECRET_BYBIT_KEY="your_bybit_api_key"
   export ABACUS_SECRET_BYBIT_SECRET="your_bybit_api_secret"
   
   export ABACUS_SECRET_OKX_KEY="your_okx_api_key"
   export ABACUS_SECRET_OKX_SECRET="your_okx_api_secret"
   export ABACUS_SECRET_OKX_PASSPHRASE="your_okx_passphrase"
   
   export ABACUS_SECRET_BINANCE_KEY="your_binance_api_key"
   export ABACUS_SECRET_BINANCE_SECRET="your_binance_api_secret"
   ```

## Configuration

The bot is configured using YAML files in the `config` directory:

- `config/env.yaml`: Main configuration file
- `config/testnet/config.yaml`: TESTNET-specific configuration
- `config/mainnet/config.yaml`: MAINNET-specific configuration

### Main Configuration Options

```yaml
# Trading parameters
trading_interval: 60  # seconds between strategy executions

# Strategy configuration
strategy:
  symbol: "BTCUSDT"
  timeframe: "1h"
  sma_fast_period: 50
  sma_slow_period: 200
  rsi_period: 14
  rsi_long_threshold: 65
  rsi_short_threshold: 35

# Risk management configuration
risk:
  risk_per_trade: 0.01  # 1% of equity per trade
  atr_period: 14
  atr_multiplier: 1.5
  
# Scheduler configuration
scheduler:
  mainnet_days: [0, 1, 2, 3, 4]  # Monday to Friday (0=Monday)
  mainnet_start_hour: 8  # 8:00 UTC
  mainnet_end_hour: 20  # 20:00 UTC
```

## Usage

### Starting the Bot

Use the provided start script:

```bash
./start.sh
```

By default, the bot starts in TESTNET mode. To start in MAINNET mode:

```bash
ENVIRONMENT=mainnet ./start.sh
```

To start in API mode (with FastAPI interface):

```bash
API_MODE=true ./start.sh
```

### Monitoring

The bot includes Prometheus and Grafana for monitoring:

1. Start the monitoring stack:
   ```
   docker-compose up -d
   ```

2. Access Grafana at http://localhost:3000 (default credentials: admin/admin)

3. Import the provided dashboards from `app/monitoring/grafana/dashboards/`

## Failover Logic

The bot implements automatic failover between exchanges:

1. **Primary Exchange**: Bybit V5 API
2. **First Failover**: OKX
3. **Second Failover**: Binance

If the primary exchange becomes unavailable, the bot automatically switches to the first failover exchange. If that also fails, it switches to the second failover exchange.

## Environment Switching

The bot can automatically switch between TESTNET and MAINNET environments based on a schedule:

- **Default**: TESTNET
- **MAINNET Hours**: Monday to Friday, 8:00-20:00 UTC (configurable)

This allows for safe testing during off-hours while trading on the main network during business hours.

## API Endpoints

When running in API mode, the following endpoints are available:

- `GET /`: Bot information
- `GET /health`: Health check
- `GET /metrics`: Prometheus metrics

## Logging

Logs are stored in the `logs` directory with automatic rotation:

- `logs/deepagent_kraken.log`: Main log file

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- Built with FastAPI, asyncio, and pandas
- Monitoring with Prometheus and Grafana
- Developed by the DeepAgent team at Abacus.AI
