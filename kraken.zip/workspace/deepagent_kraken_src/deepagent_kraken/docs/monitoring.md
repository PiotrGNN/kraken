# DeepAgent Kraken Trading Bot Monitoring

This document describes the monitoring setup for the DeepAgent Kraken trading bot using Prometheus and Grafana.

## Overview

The monitoring system consists of:

1. **Prometheus**: Collects metrics from the trading bot
2. **Grafana**: Visualizes the metrics in dashboards

The trading bot exposes metrics via a `/metrics` endpoint that Prometheus scrapes at regular intervals (every 5 seconds).

## Metrics Tracked

The following metrics are tracked:

- **P&L (Profit and Loss)**: Current profit/loss in USD
- **Equity**: Total account equity as a line chart
- **Drawdown Percentage**: Current drawdown as a percentage (turns red when > 10%)
- **Open Risk in USD**: Current amount at risk in open positions
- **Trade Count**: Total number of trades executed

## Accessing the Monitoring Dashboard

1. Start the application using Docker Compose:

   ```bash
   docker-compose up -d
   ```

2. Access Grafana at [http://localhost:3000](http://localhost:3000)

3. Login with the following credentials:
   - Username: `admin`
   - Password: `admin`

4. The Kraken Trading Bot Dashboard should be automatically loaded and available in the dashboards list.

## Prometheus

Prometheus is configured to scrape metrics from the trading bot every 5 seconds. You can access the Prometheus UI at [http://localhost:9090](http://localhost:9090) to query metrics directly or check the status of the scraping targets.

## Grafana Dashboard

The pre-configured Grafana dashboard includes:

- P&L chart showing profit and loss over time
- Equity chart showing account value over time
- Drawdown gauge with color-coded thresholds (turns red at 10%)
- Open risk stat panel showing current risk exposure
- Trade count stat panel and frequency chart

## Extending the Monitoring

To add new metrics:

1. Define new metrics in `app/utils/metrics.py`
2. Update the application code to record these metrics
3. Create new panels in the Grafana dashboard to visualize them

## Troubleshooting

If metrics are not showing up in Grafana:

1. Check if the trading bot is running and exposing metrics at `/metrics`
2. Verify that Prometheus can scrape the metrics by checking the targets page at [http://localhost:9090/targets](http://localhost:9090/targets)
3. Ensure that Grafana is properly connected to Prometheus as a data source
