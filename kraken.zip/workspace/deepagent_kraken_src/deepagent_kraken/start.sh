#!/usr/bin/env bash

# DeepAgent Kraken Trading Bot Startup Script

# Set environment variables
export PYTHONUNBUFFERED=1

# Default to testnet mode
export ENVIRONMENT=${ENVIRONMENT:-testnet}

# Check if API mode is enabled
export API_MODE=${API_MODE:-false}

# Create logs directory if it doesn't exist
mkdir -p logs

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "Creating virtual environment and installing dependencies..."
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
else
    source venv/bin/activate
fi

# Check if we need to run in API mode
if [ "$API_MODE" = "true" ]; then
    echo "Starting DeepAgent Kraken Trading Bot in API mode..."
    python main.py
else
    echo "Starting DeepAgent Kraken Trading Bot in standalone mode..."
    python main.py
fi
