"""
Trend-following strategy with RSI counter.

Strategy rules:
- SMA-50 / SMA-200 cross = direction
- Long position only when SMA50 > SMA200 and RSI-14 < 65
- Short position (on perpetual) when SMA50 < SMA200 and RSI-14 > 35
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import pandas as pd

from app.core.order_router import OrderRouter, OrderSide, OrderType
from app.strategies.indicators import calculate_sma, calculate_rsi
from app.risk.atr_risk import ATRRiskManager

logger = logging.getLogger(__name__)

class TrendFollowerStrategy:
    def __init__(self, order_router: OrderRouter, risk_manager: ATRRiskManager, config: Dict[str, Any]):
        """
        Initialize the trend follower strategy.
        
        Args:
            order_router: Order router instance
            risk_manager: Risk manager instance
            config: Strategy configuration
        """
        self.order_router = order_router
        self.risk_manager = risk_manager
        self.config = config
        
        # Strategy parameters
        self.symbol = config.get("symbol", "BTCUSDT")
        self.timeframe = config.get("timeframe", "1h")
        self.sma_fast_period = config.get("sma_fast_period", 50)
        self.sma_slow_period = config.get("sma_slow_period", 200)
        self.rsi_period = config.get("rsi_period", 14)
        self.rsi_long_threshold = config.get("rsi_long_threshold", 65)
        self.rsi_short_threshold = config.get("rsi_short_threshold", 35)
        
        # Position tracking
        self.current_position = 0  # 0 = no position, 1 = long, -1 = short
        self.position_size = 0
        self.entry_price = 0
        self.stop_loss_id = None
        self.trailing_stop_id = None
        
        logger.info(f"Trend follower strategy initialized for {self.symbol} on {self.timeframe} timeframe")

    async def fetch_market_data(self) -> pd.DataFrame:
        """
        Fetch market data and calculate indicators.
        
        Returns:
            DataFrame with market data and indicators
        """
        try:
            # Fetch klines from the exchange
            klines = await self.order_router.get_klines(
                symbol=self.symbol,
                interval=self.timeframe,
                limit=300  # Need at least 200 bars for SMA-200
            )
            
            # Convert to DataFrame
            df = pd.DataFrame(klines)
            
            # Ensure we have the required columns
            required_columns = ['open_time', 'open', 'high', 'low', 'close', 'volume']
            if not all(col in df.columns for col in required_columns):
                # Try to adapt to different exchange formats
                if 'timestamp' in df.columns:
                    df['open_time'] = df['timestamp']
                
                # Map column names if needed
                column_mapping = {
                    'open_price': 'open',
                    'high_price': 'high',
                    'low_price': 'low',
                    'close_price': 'close',
                }
                
                df = df.rename(columns={k: v for k, v in column_mapping.items() if k in df.columns})
            
            # Convert string values to float
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Calculate indicators
            df['sma_fast'] = calculate_sma(df['close'], self.sma_fast_period)
            df['sma_slow'] = calculate_sma(df['close'], self.sma_slow_period)
            df['rsi'] = calculate_rsi(df['close'], self.rsi_period)
            
            # Calculate ATR for risk management
            df['atr'] = self.risk_manager.calculate_atr(df)
            
            return df
        except Exception as e:
            logger.error(f"Error fetching market data: {e}")
            raise

    def analyze_market(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Analyze market data and generate trading signals.
        
        Args:
            df: DataFrame with market data and indicators
            
        Returns:
            Dictionary with analysis results
        """
        try:
            # Get the latest data
            latest = df.iloc[-1]
            
            # Determine trend direction
            trend_up = latest['sma_fast'] > latest['sma_slow']
            
            # Check RSI conditions
            rsi = latest['rsi']
            rsi_long_signal = rsi < self.rsi_long_threshold
            rsi_short_signal = rsi > self.rsi_short_threshold
            
            # Generate signals
            long_signal = trend_up and rsi_long_signal
            short_signal = not trend_up and rsi_short_signal
            
            # Current price
            current_price = latest['close']
            
            # ATR for risk management
            atr = latest['atr']
            
            return {
                'trend_up': trend_up,
                'rsi': rsi,
                'long_signal': long_signal,
                'short_signal': short_signal,
                'current_price': current_price,
                'atr': atr
            }
        except Exception as e:
            logger.error(f"Error analyzing market: {e}")
            raise

    async def execute_strategy(self) -> Dict[str, Any]:
        """
        Execute the trading strategy.
        
        Returns:
            Dictionary with execution results
        """
        try:
            # Fetch market data
            df = await self.fetch_market_data()
            
            # Analyze market
            analysis = self.analyze_market(df)
            
            # Get current position
            position = await self.order_router.get_position(self.symbol)
            self.current_position = 1 if position.get('size', 0) > 0 else (-1 if position.get('size', 0) < 0 else 0)
            self.position_size = abs(position.get('size', 0))
            self.entry_price = position.get('entry_price', 0)
            
            # Get account balance for position sizing
            account = await self.order_router.get_account_balance()
            equity = account.get('equity', 0)
            
            # Execute trading logic
            result = await self._execute_trading_logic(analysis, equity)
            
            return result
        except Exception as e:
            logger.error(f"Error executing strategy: {e}")
            raise

    async def _execute_trading_logic(self, analysis: Dict[str, Any], equity: float) -> Dict[str, Any]:
        """
        Execute trading logic based on market analysis.
        
        Args:
            analysis: Market analysis results
            equity: Account equity
            
        Returns:
            Dictionary with execution results
        """
        current_price = analysis['current_price']
        atr = analysis['atr']
        
        # No position - check for entry signals
        if self.current_position == 0:
            if analysis['long_signal']:
                # Calculate position size based on risk
                position_size = self.risk_manager.calculate_position_size(
                    equity=equity,
                    atr=atr,
                    current_price=current_price
                )
                
                # Place long order
                order = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.BUY,
                    order_type=OrderType.MARKET,
                    quantity=position_size
                )
                
                # Place stop loss
                stop_price = current_price - (1.5 * atr)
                stop_loss = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.SELL,
                    order_type=OrderType.STOP_MARKET,
                    quantity=position_size,
                    stop_price=stop_price,
                    reduce_only=True
                )
                
                self.current_position = 1
                self.position_size = position_size
                self.entry_price = current_price
                self.stop_loss_id = stop_loss.get('order_id')
                
                logger.info(f"Opened LONG position: {position_size} {self.symbol} at {current_price}, stop at {stop_price}")
                
                return {
                    'action': 'open_long',
                    'price': current_price,
                    'size': position_size,
                    'stop_price': stop_price
                }
                
            elif analysis['short_signal']:
                # Calculate position size based on risk
                position_size = self.risk_manager.calculate_position_size(
                    equity=equity,
                    atr=atr,
                    current_price=current_price
                )
                
                # Place short order
                order = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.SELL,
                    order_type=OrderType.MARKET,
                    quantity=position_size
                )
                
                # Place stop loss
                stop_price = current_price + (1.5 * atr)
                stop_loss = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.BUY,
                    order_type=OrderType.STOP_MARKET,
                    quantity=position_size,
                    stop_price=stop_price,
                    reduce_only=True
                )
                
                self.current_position = -1
                self.position_size = position_size
                self.entry_price = current_price
                self.stop_loss_id = stop_loss.get('order_id')
                
                logger.info(f"Opened SHORT position: {position_size} {self.symbol} at {current_price}, stop at {stop_price}")
                
                return {
                    'action': 'open_short',
                    'price': current_price,
                    'size': position_size,
                    'stop_price': stop_price
                }
            
            return {'action': 'no_action'}
        
        # Long position - check for exit or trailing stop update
        elif self.current_position == 1:
            # Exit if trend changes or RSI is too high
            if not analysis['trend_up'] or analysis['rsi'] >= self.rsi_long_threshold:
                # Close position
                order = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.SELL,
                    order_type=OrderType.MARKET,
                    quantity=self.position_size,
                    reduce_only=True
                )
                
                # Cancel stop loss
                if self.stop_loss_id:
                    await self.order_router.cancel_order(self.stop_loss_id, self.symbol)
                    self.stop_loss_id = None
                
                # Cancel trailing stop
                if self.trailing_stop_id:
                    await self.order_router.cancel_order(self.trailing_stop_id, self.symbol)
                    self.trailing_stop_id = None
                
                profit = (current_price - self.entry_price) * self.position_size
                logger.info(f"Closed LONG position: {self.position_size} {self.symbol} at {current_price}, profit: {profit}")
                
                self.current_position = 0
                self.position_size = 0
                self.entry_price = 0
                
                return {
                    'action': 'close_long',
                    'price': current_price,
                    'profit': profit
                }
            
            # Check if we need to update trailing stop
            price_move = current_price - self.entry_price
            
            # Move to breakeven after +1 ATR
            if price_move > atr and self.stop_loss_id:
                # Cancel existing stop loss
                await self.order_router.cancel_order(self.stop_loss_id, self.symbol)
                
                # Place new stop at breakeven
                stop_price = self.entry_price
                stop_loss = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.SELL,
                    order_type=OrderType.STOP_MARKET,
                    quantity=self.position_size,
                    stop_price=stop_price,
                    reduce_only=True
                )
                
                self.stop_loss_id = stop_loss.get('order_id')
                logger.info(f"Updated stop loss to breakeven: {stop_price}")
                
                return {
                    'action': 'update_stop',
                    'stop_price': stop_price
                }
            
            # Trail by 0.5 ATR after +1 ATR
            elif price_move > atr:
                # Calculate new trailing stop
                new_stop = current_price - (0.5 * atr)
                
                # Only update if it's higher than the current stop
                if not self.trailing_stop_id:
                    # Place trailing stop
                    trailing_stop = await self.order_router.place_order(
                        symbol=self.symbol,
                        side=OrderSide.SELL,
                        order_type=OrderType.TRAILING_STOP,
                        quantity=self.position_size,
                        activation_price=current_price,
                        callback_rate=0.5,  # 0.5% callback rate
                        reduce_only=True
                    )
                    
                    self.trailing_stop_id = trailing_stop.get('order_id')
                    logger.info(f"Placed trailing stop at {new_stop}")
                    
                    return {
                        'action': 'place_trailing_stop',
                        'stop_price': new_stop
                    }
            
            return {'action': 'hold_long'}
        
        # Short position - check for exit or trailing stop update
        elif self.current_position == -1:
            # Exit if trend changes or RSI is too low
            if analysis['trend_up'] or analysis['rsi'] <= self.rsi_short_threshold:
                # Close position
                order = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.BUY,
                    order_type=OrderType.MARKET,
                    quantity=self.position_size,
                    reduce_only=True
                )
                
                # Cancel stop loss
                if self.stop_loss_id:
                    await self.order_router.cancel_order(self.stop_loss_id, self.symbol)
                    self.stop_loss_id = None
                
                # Cancel trailing stop
                if self.trailing_stop_id:
                    await self.order_router.cancel_order(self.trailing_stop_id, self.symbol)
                    self.trailing_stop_id = None
                
                profit = (self.entry_price - current_price) * self.position_size
                logger.info(f"Closed SHORT position: {self.position_size} {self.symbol} at {current_price}, profit: {profit}")
                
                self.current_position = 0
                self.position_size = 0
                self.entry_price = 0
                
                return {
                    'action': 'close_short',
                    'price': current_price,
                    'profit': profit
                }
            
            # Check if we need to update trailing stop
            price_move = self.entry_price - current_price
            
            # Move to breakeven after +1 ATR
            if price_move > atr and self.stop_loss_id:
                # Cancel existing stop loss
                await self.order_router.cancel_order(self.stop_loss_id, self.symbol)
                
                # Place new stop at breakeven
                stop_price = self.entry_price
                stop_loss = await self.order_router.place_order(
                    symbol=self.symbol,
                    side=OrderSide.BUY,
                    order_type=OrderType.STOP_MARKET,
                    quantity=self.position_size,
                    stop_price=stop_price,
                    reduce_only=True
                )
                
                self.stop_loss_id = stop_loss.get('order_id')
                logger.info(f"Updated stop loss to breakeven: {stop_price}")
                
                return {
                    'action': 'update_stop',
                    'stop_price': stop_price
                }
            
            # Trail by 0.5 ATR after +1 ATR
            elif price_move > atr:
                # Calculate new trailing stop
                new_stop = current_price + (0.5 * atr)
                
                # Only update if it's lower than the current stop
                if not self.trailing_stop_id:
                    # Place trailing stop
                    trailing_stop = await self.order_router.place_order(
                        symbol=self.symbol,
                        side=OrderSide.BUY,
                        order_type=OrderType.TRAILING_STOP,
                        quantity=self.position_size,
                        activation_price=current_price,
                        callback_rate=0.5,  # 0.5% callback rate
                        reduce_only=True
                    )
                    
                    self.trailing_stop_id = trailing_stop.get('order_id')
                    logger.info(f"Placed trailing stop at {new_stop}")
                    
                    return {
                        'action': 'place_trailing_stop',
                        'stop_price': new_stop
                    }
            
            return {'action': 'hold_short'}
