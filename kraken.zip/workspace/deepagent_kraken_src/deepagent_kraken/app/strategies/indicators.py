"""
Technical indicators implementation.
"""

import numpy as np
import pandas as pd
from typing import Union, List

def calculate_sma(data: Union[List[float], pd.Series], period: int) -> pd.Series:
    """
    Calculate Simple Moving Average.
    
    Args:
        data: Price data
        period: SMA period
        
    Returns:
        Series with SMA values
    """
    if isinstance(data, list):
        data = pd.Series(data)
    
    return data.rolling(window=period).mean()

def calculate_ema(data: Union[List[float], pd.Series], period: int) -> pd.Series:
    """
    Calculate Exponential Moving Average.
    
    Args:
        data: Price data
        period: EMA period
        
    Returns:
        Series with EMA values
    """
    if isinstance(data, list):
        data = pd.Series(data)
    
    return data.ewm(span=period, adjust=False).mean()

def calculate_rsi(data: Union[List[float], pd.Series], period: int = 14) -> pd.Series:
    """
    Calculate Relative Strength Index.
    
    Args:
        data: Price data
        period: RSI period
        
    Returns:
        Series with RSI values
    """
    if isinstance(data, list):
        data = pd.Series(data)
    
    # Calculate price changes
    delta = data.diff()
    
    # Separate gains and losses
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    
    # Calculate average gain and loss
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    
    # Calculate RS
    rs = avg_gain / avg_loss
    
    # Calculate RSI
    rsi = 100 - (100 / (1 + rs))
    
    return rsi

def calculate_macd(data: Union[List[float], pd.Series], fast_period: int = 12, 
                  slow_period: int = 26, signal_period: int = 9) -> tuple:
    """
    Calculate MACD (Moving Average Convergence Divergence).
    
    Args:
        data: Price data
        fast_period: Fast EMA period
        slow_period: Slow EMA period
        signal_period: Signal EMA period
        
    Returns:
        Tuple of (MACD line, Signal line, Histogram)
    """
    if isinstance(data, list):
        data = pd.Series(data)
    
    # Calculate fast and slow EMAs
    fast_ema = calculate_ema(data, fast_period)
    slow_ema = calculate_ema(data, slow_period)
    
    # Calculate MACD line
    macd_line = fast_ema - slow_ema
    
    # Calculate signal line
    signal_line = calculate_ema(macd_line, signal_period)
    
    # Calculate histogram
    histogram = macd_line - signal_line
    
    return macd_line, signal_line, histogram

def calculate_bollinger_bands(data: Union[List[float], pd.Series], period: int = 20, 
                             std_dev: float = 2.0) -> tuple:
    """
    Calculate Bollinger Bands.
    
    Args:
        data: Price data
        period: SMA period
        std_dev: Standard deviation multiplier
        
    Returns:
        Tuple of (Upper band, Middle band, Lower band)
    """
    if isinstance(data, list):
        data = pd.Series(data)
    
    # Calculate middle band (SMA)
    middle_band = calculate_sma(data, period)
    
    # Calculate standard deviation
    std = data.rolling(window=period).std()
    
    # Calculate upper and lower bands
    upper_band = middle_band + (std_dev * std)
    lower_band = middle_band - (std_dev * std)
    
    return upper_band, middle_band, lower_band

def calculate_atr(high: Union[List[float], pd.Series], 
                 low: Union[List[float], pd.Series], 
                 close: Union[List[float], pd.Series], 
                 period: int = 14) -> pd.Series:
    """
    Calculate Average True Range.
    
    Args:
        high: High prices
        low: Low prices
        close: Close prices
        period: ATR period
        
    Returns:
        Series with ATR values
    """
    if isinstance(high, list):
        high = pd.Series(high)
    if isinstance(low, list):
        low = pd.Series(low)
    if isinstance(close, list):
        close = pd.Series(close)
    
    # Calculate true range
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    # Calculate ATR
    atr = tr.rolling(window=period).mean()
    
    return atr

def calculate_stochastic(high: Union[List[float], pd.Series], 
                        low: Union[List[float], pd.Series], 
                        close: Union[List[float], pd.Series], 
                        k_period: int = 14, 
                        d_period: int = 3) -> tuple:
    """
    Calculate Stochastic Oscillator.
    
    Args:
        high: High prices
        low: Low prices
        close: Close prices
        k_period: %K period
        d_period: %D period
        
    Returns:
        Tuple of (%K, %D)
    """
    if isinstance(high, list):
        high = pd.Series(high)
    if isinstance(low, list):
        low = pd.Series(low)
    if isinstance(close, list):
        close = pd.Series(close)
    
    # Calculate %K
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    
    k = 100 * ((close - lowest_low) / (highest_high - lowest_low))
    
    # Calculate %D
    d = k.rolling(window=d_period).mean()
    
    return k, d
