"""
Factory for creating exchange connectors.
"""

import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class ConnectorFactory:
    def __init__(self, env_manager):
        """
        Initialize the connector factory.
        
        Args:
            env_manager: Environment manager instance
        """
        self.env_manager = env_manager
        self.connectors = {}  # Cache for initialized connectors

    def create_connector(self, exchange: str) -> Any:
        """
        Create and return an exchange connector.
        
        Args:
            exchange: Exchange name (bybit, okx, binance)
            
        Returns:
            Exchange connector instance
            
        Raises:
            ValueError: If the exchange is not supported
        """
        # Check if connector is already initialized
        if exchange in self.connectors:
            return self.connectors[exchange]
        
        # Get API keys for the exchange
        api_keys = self.env_manager.get_api_keys(exchange)
        if not api_keys:
            raise ValueError(f"No API keys found for {exchange}")
        
        # Get exchange URLs for the current environment
        exchange_urls = self.env_manager.get_exchange_urls()
        base_url = exchange_urls.get(exchange)
        
        if not base_url:
            raise ValueError(f"No base URL found for {exchange}")
        
        # Create the appropriate connector based on the exchange
        if exchange == "bybit":
            from app.connectors.bybit.v5_connector import BybitV5Connector
            connector = BybitV5Connector(
                api_key=api_keys["api_key"],
                api_secret=api_keys["api_secret"],
                base_url=base_url,
                testnet=self.env_manager.is_testnet()
            )
        elif exchange == "okx":
            from app.connectors.okx.connector import OKXConnector
            connector = OKXConnector(
                api_key=api_keys["api_key"],
                api_secret=api_keys["api_secret"],
                passphrase=api_keys["passphrase"],
                base_url=base_url,
                testnet=self.env_manager.is_testnet()
            )
        elif exchange == "binance":
            from app.connectors.binance.connector import BinanceConnector
            connector = BinanceConnector(
                api_key=api_keys["api_key"],
                api_secret=api_keys["api_secret"],
                base_url=base_url,
                testnet=self.env_manager.is_testnet()
            )
        else:
            raise ValueError(f"Unsupported exchange: {exchange}")
        
        # Cache the connector
        self.connectors[exchange] = connector
        logger.info(f"Created connector for {exchange}")
        
        return connector
