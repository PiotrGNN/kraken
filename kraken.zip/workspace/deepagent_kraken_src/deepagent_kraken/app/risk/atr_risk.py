"""
ATR-based risk management.

Risk management rules:
1. Position sizing = equity × 1% / (ATR14 × 1.5)
2. Stop-Loss = 1.5 × ATR (server-side)
3. Trailing-stop = move to breakeven after +1 ATR, then step by 0.5 ATR
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, Union, List

logger = logging.getLogger(__name__)

class ATRRiskManager:
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the ATR risk manager.
        
        Args:
            config: Risk management configuration
        """
        self.config = config
        
        # Risk parameters
        self.risk_per_trade = config.get("risk_per_trade", 0.01)  # 1% of equity
        self.atr_period = config.get("atr_period", 14)
        self.atr_multiplier = config.get("atr_multiplier", 1.5)  # For stop loss
        self.breakeven_threshold = config.get("breakeven_threshold", 1.0)  # Move to breakeven after +1 ATR
        self.trailing_step = config.get("trailing_step", 0.5)  # Trail by 0.5 ATR
        
        logger.info(f"ATR risk manager initialized with risk per trade: {self.risk_per_trade}, "
                   f"ATR period: {self.atr_period}, ATR multiplier: {self.atr_multiplier}")

    def calculate_atr(self, df: pd.DataFrame) -> pd.Series:
        """
        Calculate Average True Range.
        
        Args:
            df: DataFrame with OHLC data
            
        Returns:
            Series with ATR values
        """
        # Ensure we have the required columns
        required_columns = ['high', 'low', 'close']
        if not all(col in df.columns for col in required_columns):
            raise ValueError(f"DataFrame must contain columns: {required_columns}")
        
        # Calculate true range
        prev_close = df['close'].shift(1)
        tr1 = df['high'] - df['low']
        tr2 = (df['high'] - prev_close).abs()
        tr3 = (df['low'] - prev_close).abs()
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        
        # Calculate ATR
        atr = tr.rolling(window=self.atr_period).mean()
        
        return atr

    def calculate_position_size(self, equity: float, atr: float, current_price: float) -> float:
        """
        Calculate position size based on ATR and risk parameters.
        
        Formula: position_size = equity × risk_per_trade / (ATR × atr_multiplier)
        
        Args:
            equity: Account equity
            atr: Current ATR value
            current_price: Current price
            
        Returns:
            Position size in base currency
        """
        if atr <= 0:
            logger.warning("ATR is zero or negative, using default value")
            atr = current_price * 0.01  # Default to 1% of price
        
        # Calculate dollar risk amount
        dollar_risk = equity * self.risk_per_trade
        
        # Calculate stop loss distance in dollars
        stop_distance = atr * self.atr_multiplier
        
        # Calculate position size in base currency
        position_size = dollar_risk / stop_distance
        
        # Convert to contract size
        contract_size = position_size / current_price
        
        # Round to appropriate precision
        precision = self.config.get("size_precision", 3)
        contract_size = round(contract_size, precision)
        
        # Ensure minimum position size
        min_size = self.config.get("min_size", 0.001)
        if contract_size < min_size:
            contract_size = min_size
            logger.warning(f"Position size adjusted to minimum: {min_size}")
        
        # Ensure maximum position size
        max_size = self.config.get("max_size", float('inf'))
        if contract_size > max_size:
            contract_size = max_size
            logger.warning(f"Position size adjusted to maximum: {max_size}")
        
        logger.info(f"Calculated position size: {contract_size} contracts, "
                   f"dollar risk: ${dollar_risk}, stop distance: ${stop_distance}")
        
        return contract_size

    def calculate_stop_loss(self, entry_price: float, atr: float, is_long: bool) -> float:
        """
        Calculate stop loss price based on ATR.
        
        Args:
            entry_price: Entry price
            atr: Current ATR value
            is_long: Whether the position is long
            
        Returns:
            Stop loss price
        """
        stop_distance = atr * self.atr_multiplier
        
        if is_long:
            stop_price = entry_price - stop_distance
        else:
            stop_price = entry_price + stop_distance
        
        # Round to appropriate precision
        precision = self.config.get("price_precision", 2)
        stop_price = round(stop_price, precision)
        
        logger.info(f"Calculated stop loss: {stop_price}, distance: {stop_distance}")
        
        return stop_price

    def calculate_trailing_stop(self, entry_price: float, current_price: float, 
                               atr: float, is_long: bool) -> Optional[float]:
        """
        Calculate trailing stop price based on ATR.
        
        Args:
            entry_price: Entry price
            current_price: Current price
            atr: Current ATR value
            is_long: Whether the position is long
            
        Returns:
            Trailing stop price or None if not triggered
        """
        if is_long:
            # Check if price has moved enough to trigger trailing stop
            price_move = current_price - entry_price
            atr_threshold = atr * self.breakeven_threshold
            
            if price_move < atr_threshold:
                return None  # Not enough movement to trigger trailing stop
            
            # Calculate trailing stop
            if price_move >= atr_threshold and price_move < atr_threshold * 2:
                # Move to breakeven
                stop_price = entry_price
            else:
                # Trail by trailing_step * ATR
                stop_price = current_price - (atr * self.trailing_step)
                
        else:  # Short position
            # Check if price has moved enough to trigger trailing stop
            price_move = entry_price - current_price
            atr_threshold = atr * self.breakeven_threshold
            
            if price_move < atr_threshold:
                return None  # Not enough movement to trigger trailing stop
            
            # Calculate trailing stop
            if price_move >= atr_threshold and price_move < atr_threshold * 2:
                # Move to breakeven
                stop_price = entry_price
            else:
                # Trail by trailing_step * ATR
                stop_price = current_price + (atr * self.trailing_step)
        
        # Round to appropriate precision
        precision = self.config.get("price_precision", 2)
        stop_price = round(stop_price, precision)
        
        logger.info(f"Calculated trailing stop: {stop_price}")
        
        return stop_price

    def calculate_take_profit(self, entry_price: float, atr: float, 
                             is_long: bool, risk_reward_ratio: float = 2.0) -> float:
        """
        Calculate take profit price based on ATR and risk-reward ratio.
        
        Args:
            entry_price: Entry price
            atr: Current ATR value
            is_long: Whether the position is long
            risk_reward_ratio: Risk-reward ratio
            
        Returns:
            Take profit price
        """
        stop_distance = atr * self.atr_multiplier
        take_profit_distance = stop_distance * risk_reward_ratio
        
        if is_long:
            take_profit_price = entry_price + take_profit_distance
        else:
            take_profit_price = entry_price - take_profit_distance
        
        # Round to appropriate precision
        precision = self.config.get("price_precision", 2)
        take_profit_price = round(take_profit_price, precision)
        
        logger.info(f"Calculated take profit: {take_profit_price}, "
                   f"distance: {take_profit_distance}, risk-reward: {risk_reward_ratio}")
        
        return take_profit_price

    def is_risk_acceptable(self, equity: float, position_size: float, 
                          atr: float, current_price: float) -> bool:
        """
        Check if the risk is acceptable.
        
        Args:
            equity: Account equity
            position_size: Position size in base currency
            atr: Current ATR value
            current_price: Current price
            
        Returns:
            True if risk is acceptable, False otherwise
        """
        # Calculate dollar risk
        stop_distance = atr * self.atr_multiplier
        dollar_risk = position_size * stop_distance
        
        # Calculate risk percentage
        risk_percentage = dollar_risk / equity
        
        # Check if risk is acceptable
        max_risk = self.config.get("max_risk_per_trade", 0.02)  # 2% max risk
        
        if risk_percentage > max_risk:
            logger.warning(f"Risk too high: {risk_percentage:.2%}, max allowed: {max_risk:.2%}")
            return False
        
        logger.info(f"Risk acceptable: {risk_percentage:.2%}, max allowed: {max_risk:.2%}")
        return True
