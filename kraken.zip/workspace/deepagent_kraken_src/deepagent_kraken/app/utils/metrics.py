"""
Metrics collection for Prometheus monitoring.
"""

import logging
from typing import Dict, Any
from fastapi import FastAPI
from prometheus_client import Counter, Gauge, start_http_server
from prometheus_fastapi_instrumentator import Instrumentator

logger = logging.getLogger(__name__)

# Define Prometheus metrics
TRADE_COUNT = Counter('deepagent_trade_count', 'Number of trades executed')
FAILOVER_COUNT = Counter('deepagent_failover_count', 'Number of exchange failovers')
PNL = Gauge('deepagent_pnl', 'Current unrealized PnL')
EQUITY = Gauge('deepagent_equity', 'Current account equity')
OPEN_RISK = Gauge('deepagent_open_risk', 'Current open risk')
EXCHANGE_STATUS = Gauge('deepagent_exchange_status', 'Exchange status (1=healthy, 0=unhealthy)', ['exchange'])

# Initialize exchange status metrics
for exchange in ['bybit', 'okx', 'binance']:
    EXCHANGE_STATUS.labels(exchange=exchange).set(0)

def setup_metrics(app: FastAPI) -> FastAPI:
    """
    Setup Prometheus metrics for FastAPI.
    
    Args:
        app: FastAPI application
        
    Returns:
        FastAPI application with metrics
    """
    # Add Prometheus metrics to FastAPI
    Instrumentator().instrument(app).expose(app)
    
    # Start Prometheus metrics server
    try:
        start_http_server(8000)
        logger.info("Prometheus metrics server started on port 8000")
    except Exception as e:
        logger.error(f"Failed to start Prometheus metrics server: {e}")
    
    return app

def increment_trade_count() -> None:
    """Increment the trade count metric."""
    TRADE_COUNT.inc()

def increment_failover_count() -> None:
    """Increment the failover count metric."""
    FAILOVER_COUNT.inc()

def update_pnl(pnl: float) -> None:
    """Update the PnL metric."""
    PNL.set(pnl)

def update_equity(equity: float) -> None:
    """Update the equity metric."""
    EQUITY.set(equity)

def update_open_risk(risk: float) -> None:
    """Update the open risk metric."""
    OPEN_RISK.set(risk)

def update_exchange_status(exchange: str, status: int) -> None:
    """
    Update the exchange status metric.
    
    Args:
        exchange: Exchange name
        status: 1 for healthy, 0 for unhealthy
    """
    EXCHANGE_STATUS.labels(exchange=exchange).set(status)
