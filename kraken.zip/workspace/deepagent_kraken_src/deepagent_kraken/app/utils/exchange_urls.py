"""
Exchange URL configuration for different environments.
"""

from typing import Dict
from app.core.env_manager import Environment

def get_exchange_urls(environment: Environment) -> Dict[str, str]:
    """
    Get the appropriate URLs for the specified environment.
    
    Args:
        environment: Environment enum (TESTNET or MAINNET)
        
    Returns:
        Dictionary of exchange URLs
    """
    if environment == Environment.TESTNET:
        return {
            "bybit": "https://api-testnet.bybit.com",
            "okx": "https://www.okx.com/api/v5/mock-trading",
            "binance": "https://testnet.binance.vision/api"
        }
    else:  # MAINNET
        return {
            "bybit": "https://api.bybit.com",
            "okx": "https://www.okx.com/api/v5",
            "binance": "https://api.binance.com/api"
        }
