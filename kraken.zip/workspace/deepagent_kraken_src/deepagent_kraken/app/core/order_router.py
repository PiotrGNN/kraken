"""
Order router with failover logic between multiple exchange connectors.
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from enum import Enum

from app.connectors.connector_factory import ConnectorFactory
from app.utils.metrics import increment_failover_count, update_exchange_status

logger = logging.getLogger(__name__)

class OrderType(Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP_MARKET = "stop_market"
    STOP_LIMIT = "stop_limit"
    TRAILING_STOP = "trailing_stop"

class OrderSide(Enum):
    BUY = "buy"
    SELL = "sell"

class OrderRouter:
    def __init__(self, env_manager, primary_exchange="bybit", failover_exchanges=None):
        """
        Initialize the order router with primary and failover exchanges.
        
        Args:
            env_manager: Environment manager instance
            primary_exchange: Primary exchange to use (default: bybit)
            failover_exchanges: List of failover exchanges in priority order (default: ["okx", "binance"])
        """
        self.env_manager = env_manager
        self.primary_exchange = primary_exchange
        self.failover_exchanges = failover_exchanges or ["okx", "binance"]
        self.exchange_order = [primary_exchange] + self.failover_exchanges
        
        # Initialize exchange connectors
        self.connectors = {}
        self._initialize_connectors()
        
        # Track exchange health
        self.exchange_health = {exchange: True for exchange in self.exchange_order}
        
        # Current active exchange
        self.active_exchange = primary_exchange
        
        logger.info(f"Order router initialized with primary exchange: {primary_exchange}, "
                   f"failover exchanges: {self.failover_exchanges}")

    def _initialize_connectors(self):
        """Initialize all exchange connectors."""
        factory = ConnectorFactory(self.env_manager)
        
        for exchange in self.exchange_order:
            try:
                self.connectors[exchange] = factory.create_connector(exchange)
                logger.info(f"Initialized connector for {exchange}")
                update_exchange_status(exchange, 1)  # 1 = healthy
            except Exception as e:
                logger.error(f"Failed to initialize connector for {exchange}: {e}")
                self.exchange_health[exchange] = False
                update_exchange_status(exchange, 0)  # 0 = unhealthy
        
        # If primary exchange is unhealthy, try to failover immediately
        if not self.exchange_health[self.primary_exchange]:
            self._failover()

    async def _check_exchange_health(self, exchange: str) -> bool:
        """Check if an exchange is healthy by pinging its API."""
        try:
            connector = self.connectors.get(exchange)
            if not connector:
                return False
                
            # Attempt to get account balance or ticker data to verify connectivity
            await connector.get_account_balance()
            self.exchange_health[exchange] = True
            update_exchange_status(exchange, 1)  # 1 = healthy
            return True
        except Exception as e:
            logger.warning(f"Health check failed for {exchange}: {e}")
            self.exchange_health[exchange] = False
            update_exchange_status(exchange, 0)  # 0 = unhealthy
            return False

    def _failover(self) -> bool:
        """
        Attempt to failover to the next healthy exchange.
        Returns True if failover was successful, False otherwise.
        """
        current_index = self.exchange_order.index(self.active_exchange)
        
        # Try each exchange in order
        for i in range(current_index + 1, len(self.exchange_order)):
            exchange = self.exchange_order[i]
            if self.exchange_health[exchange]:
                self.active_exchange = exchange
                logger.warning(f"Failing over from {self.exchange_order[current_index]} to {exchange}")
                increment_failover_count()
                return True
        
        # If we get here, no healthy failover exchange was found
        logger.error("No healthy exchange available for failover")
        return False

    async def place_order(self, symbol: str, side: OrderSide, order_type: OrderType, 
                         quantity: float, price: Optional[float] = None, 
                         stop_price: Optional[float] = None, 
                         time_in_force: str = "GTC", 
                         reduce_only: bool = False,
                         **kwargs) -> Dict[str, Any]:
        """
        Place an order with failover capability.
        
        Args:
            symbol: Trading pair symbol
            side: Order side (buy/sell)
            order_type: Type of order
            quantity: Order quantity
            price: Order price (required for limit orders)
            stop_price: Stop price (required for stop orders)
            time_in_force: Time in force (GTC, IOC, FOK)
            reduce_only: Whether the order should only reduce position
            **kwargs: Additional parameters specific to exchanges
            
        Returns:
            Order details from the exchange
        """
        # Check if active exchange is healthy
        if not await self._check_exchange_health(self.active_exchange):
            if not self._failover():
                raise Exception("No healthy exchange available to place order")
        
        # Get the active connector
        connector = self.connectors[self.active_exchange]
        
        try:
            # Place the order on the active exchange
            order = await connector.place_order(
                symbol=symbol,
                side=side.value,
                order_type=order_type.value,
                quantity=quantity,
                price=price,
                stop_price=stop_price,
                time_in_force=time_in_force,
                reduce_only=reduce_only,
                **kwargs
            )
            
            logger.info(f"Order placed on {self.active_exchange}: {order}")
            return order
        except Exception as e:
            logger.error(f"Failed to place order on {self.active_exchange}: {e}")
            
            # Try failover
            if self._failover():
                logger.info(f"Retrying order on {self.active_exchange}")
                return await self.place_order(
                    symbol=symbol,
                    side=side,
                    order_type=order_type,
                    quantity=quantity,
                    price=price,
                    stop_price=stop_price,
                    time_in_force=time_in_force,
                    reduce_only=reduce_only,
                    **kwargs
                )
            else:
                raise Exception("Failed to place order and no healthy exchange available for failover")

    async def cancel_order(self, order_id: str, symbol: str) -> Dict[str, Any]:
        """Cancel an order with failover capability."""
        # Check if active exchange is healthy
        if not await self._check_exchange_health(self.active_exchange):
            if not self._failover():
                raise Exception("No healthy exchange available to cancel order")
        
        # Get the active connector
        connector = self.connectors[self.active_exchange]
        
        try:
            # Cancel the order on the active exchange
            result = await connector.cancel_order(order_id=order_id, symbol=symbol)
            logger.info(f"Order {order_id} cancelled on {self.active_exchange}")
            return result
        except Exception as e:
            logger.error(f"Failed to cancel order on {self.active_exchange}: {e}")
            
            # Try failover
            if self._failover():
                logger.info(f"Retrying cancel order on {self.active_exchange}")
                return await self.cancel_order(order_id=order_id, symbol=symbol)
            else:
                raise Exception("Failed to cancel order and no healthy exchange available for failover")

    async def get_position(self, symbol: str) -> Dict[str, Any]:
        """Get current position with failover capability."""
        # Check if active exchange is healthy
        if not await self._check_exchange_health(self.active_exchange):
            if not self._failover():
                raise Exception("No healthy exchange available to get position")
        
        # Get the active connector
        connector = self.connectors[self.active_exchange]
        
        try:
            # Get position from the active exchange
            position = await connector.get_position(symbol=symbol)
            return position
        except Exception as e:
            logger.error(f"Failed to get position on {self.active_exchange}: {e}")
            
            # Try failover
            if self._failover():
                logger.info(f"Retrying get position on {self.active_exchange}")
                return await self.get_position(symbol=symbol)
            else:
                raise Exception("Failed to get position and no healthy exchange available for failover")

    async def get_account_balance(self) -> Dict[str, float]:
        """Get account balance with failover capability."""
        # Check if active exchange is healthy
        if not await self._check_exchange_health(self.active_exchange):
            if not self._failover():
                raise Exception("No healthy exchange available to get account balance")
        
        # Get the active connector
        connector = self.connectors[self.active_exchange]
        
        try:
            # Get balance from the active exchange
            balance = await connector.get_account_balance()
            return balance
        except Exception as e:
            logger.error(f"Failed to get account balance on {self.active_exchange}: {e}")
            
            # Try failover
            if self._failover():
                logger.info(f"Retrying get account balance on {self.active_exchange}")
                return await self.get_account_balance()
            else:
                raise Exception("Failed to get account balance and no healthy exchange available for failover")

    async def get_ticker(self, symbol: str) -> Dict[str, float]:
        """Get ticker data with failover capability."""
        # Check if active exchange is healthy
        if not await self._check_exchange_health(self.active_exchange):
            if not self._failover():
                raise Exception("No healthy exchange available to get ticker")
        
        # Get the active connector
        connector = self.connectors[self.active_exchange]
        
        try:
            # Get ticker from the active exchange
            ticker = await connector.get_ticker(symbol=symbol)
            return ticker
        except Exception as e:
            logger.error(f"Failed to get ticker on {self.active_exchange}: {e}")
            
            # Try failover
            if self._failover():
                logger.info(f"Retrying get ticker on {self.active_exchange}")
                return await self.get_ticker(symbol=symbol)
            else:
                raise Exception("Failed to get ticker and no healthy exchange available for failover")

    async def get_klines(self, symbol: str, interval: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Get klines/candlestick data with failover capability."""
        # Check if active exchange is healthy
        if not await self._check_exchange_health(self.active_exchange):
            if not self._failover():
                raise Exception("No healthy exchange available to get klines")
        
        # Get the active connector
        connector = self.connectors[self.active_exchange]
        
        try:
            # Get klines from the active exchange
            klines = await connector.get_klines(symbol=symbol, interval=interval, limit=limit)
            return klines
        except Exception as e:
            logger.error(f"Failed to get klines on {self.active_exchange}: {e}")
            
            # Try failover
            if self._failover():
                logger.info(f"Retrying get klines on {self.active_exchange}")
                return await self.get_klines(symbol=symbol, interval=interval, limit=limit)
            else:
                raise Exception("Failed to get klines and no healthy exchange available for failover")

    async def update_trailing_stop(self, order_id: str, symbol: str, activation_price: float, 
                                  callback_rate: float) -> Dict[str, Any]:
        """Update trailing stop with failover capability."""
        # Check if active exchange is healthy
        if not await self._check_exchange_health(self.active_exchange):
            if not self._failover():
                raise Exception("No healthy exchange available to update trailing stop")
        
        # Get the active connector
        connector = self.connectors[self.active_exchange]
        
        try:
            # Update trailing stop on the active exchange
            result = await connector.update_trailing_stop(
                order_id=order_id,
                symbol=symbol,
                activation_price=activation_price,
                callback_rate=callback_rate
            )
            logger.info(f"Trailing stop updated for order {order_id} on {self.active_exchange}")
            return result
        except Exception as e:
            logger.error(f"Failed to update trailing stop on {self.active_exchange}: {e}")
            
            # Try failover
            if self._failover():
                logger.info(f"Retrying update trailing stop on {self.active_exchange}")
                return await self.update_trailing_stop(
                    order_id=order_id,
                    symbol=symbol,
                    activation_price=activation_price,
                    callback_rate=callback_rate
                )
            else:
                raise Exception("Failed to update trailing stop and no healthy exchange available for failover")

    def get_active_exchange(self) -> str:
        """Get the currently active exchange."""
        return self.active_exchange

    async def health_check_all_exchanges(self) -> Dict[str, bool]:
        """Check health of all exchanges and update status."""
        for exchange in self.exchange_order:
            await self._check_exchange_health(exchange)
        
        # If primary exchange is healthy but we're on a failover, switch back
        if (self.active_exchange != self.primary_exchange and 
            self.exchange_health[self.primary_exchange]):
            logger.info(f"Primary exchange {self.primary_exchange} is healthy again, switching back")
            self.active_exchange = self.primary_exchange
        
        return self.exchange_health
