"""
Environment manager for the DeepAgent Kraken trading bot.
Handles switching between TESTNET and MAINNET environments.
"""

import os
import yaml
import logging
from enum import Enum
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class Environment(Enum):
    TESTNET = "testnet"
    MAINNET = "mainnet"

class EnvManager:
    def __init__(self, config_dir: str = "config"):
        self.config_dir = config_dir
        self.current_env = Environment.TESTNET  # Default to TESTNET for safety
        self.config = self._load_config()
        self.api_keys = self._load_api_keys()
        logger.info(f"Environment manager initialized with {self.current_env.value} environment")

    def _load_config(self) -> Dict[str, Any]:
        """Load the environment configuration from YAML files."""
        env_file = os.path.join(self.config_dir, "env.yaml")
        env_specific_file = os.path.join(self.config_dir, self.current_env.value, "config.yaml")
        
        config = {}
        
        # Load base environment config
        if os.path.exists(env_file):
            with open(env_file, 'r') as f:
                config.update(yaml.safe_load(f) or {})
        
        # Load environment-specific config
        if os.path.exists(env_specific_file):
            with open(env_specific_file, 'r') as f:
                config.update(yaml.safe_load(f) or {})
        
        return config

    def _load_api_keys(self) -> Dict[str, Dict[str, str]]:
        """
        Load API keys from environment variables or config files.
        Prioritizes environment variables for security.
        """
        api_keys = {
            "bybit": {
                "api_key": os.getenv("ABACUS_SECRET_BYBIT_KEY", self.config.get("bybit", {}).get("api_key", "")),
                "api_secret": os.getenv("ABACUS_SECRET_BYBIT_SECRET", self.config.get("bybit", {}).get("api_secret", ""))
            },
            "okx": {
                "api_key": os.getenv("ABACUS_SECRET_OKX_KEY", self.config.get("okx", {}).get("api_key", "")),
                "api_secret": os.getenv("ABACUS_SECRET_OKX_SECRET", self.config.get("okx", {}).get("api_secret", "")),
                "passphrase": os.getenv("ABACUS_SECRET_OKX_PASSPHRASE", self.config.get("okx", {}).get("passphrase", ""))
            },
            "binance": {
                "api_key": os.getenv("ABACUS_SECRET_BINANCE_KEY", self.config.get("binance", {}).get("api_key", "")),
                "api_secret": os.getenv("ABACUS_SECRET_BINANCE_SECRET", self.config.get("binance", {}).get("api_secret", ""))
            }
        }
        
        # Validate that we have at least one set of valid API keys
        valid_keys = False
        for exchange, keys in api_keys.items():
            if all(keys.values()):
                valid_keys = True
                break
        
        if not valid_keys:
            logger.warning("No valid API keys found. Please set API keys via environment variables or config files.")
        
        return api_keys

    def switch_environment(self, env: Environment) -> None:
        """Switch between TESTNET and MAINNET environments."""
        if self.current_env == env:
            logger.info(f"Already in {env.value} environment")
            return
        
        logger.warning(f"Switching environment from {self.current_env.value} to {env.value}")
        self.current_env = env
        
        # Reload configuration for the new environment
        self.config = self._load_config()
        self.api_keys = self._load_api_keys()
        
        logger.info(f"Environment switched to {env.value}")

    def get_exchange_urls(self) -> Dict[str, str]:
        """Get the appropriate URLs for the current environment."""
        from app.utils.exchange_urls import get_exchange_urls
        return get_exchange_urls(self.current_env)

    def get_api_keys(self, exchange: str) -> Optional[Dict[str, str]]:
        """Get API keys for the specified exchange."""
        return self.api_keys.get(exchange)

    def get_config(self) -> Dict[str, Any]:
        """Get the current environment configuration."""
        return self.config

    def is_testnet(self) -> bool:
        """Check if the current environment is TESTNET."""
        return self.current_env == Environment.TESTNET

    def is_mainnet(self) -> bool:
        """Check if the current environment is MAINNET."""
        return self.current_env == Environment.MAINNET
