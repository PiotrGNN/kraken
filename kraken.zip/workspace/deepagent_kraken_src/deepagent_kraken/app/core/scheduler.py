"""
Scheduler for automatic environment switching.
"""

import asyncio
import logging
import datetime
from typing import Callable, Optional, Dict, Any

from app.core.env_manager import EnvManager, Environment

logger = logging.getLogger(__name__)

class Scheduler:
    def __init__(self, env_manager: EnvManager, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the scheduler.
        
        Args:
            env_manager: Environment manager instance
            config: Scheduler configuration
        """
        self.env_manager = env_manager
        self.config = config or {}
        self.running = False
        self.task = None
        
        # Default schedule: switch to MAINNET on Monday-Friday 8:00-20:00 UTC
        self.default_schedule = {
            "mainnet_days": [0, 1, 2, 3, 4],  # Monday to Friday (0=Monday in datetime)
            "mainnet_start_hour": 8,  # 8:00 UTC
            "mainnet_end_hour": 20,  # 20:00 UTC
        }
        
        # Override defaults with config
        if config:
            self.default_schedule.update(config)
        
        logger.info(f"Scheduler initialized with config: {self.default_schedule}")

    async def start(self) -> None:
        """Start the scheduler."""
        if self.running:
            logger.warning("Scheduler is already running")
            return
        
        self.running = True
        self.task = asyncio.create_task(self._schedule_loop())
        logger.info("Scheduler started")

    async def stop(self) -> None:
        """Stop the scheduler."""
        if not self.running:
            logger.warning("Scheduler is not running")
            return
        
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            self.task = None
        
        logger.info("Scheduler stopped")

    async def _schedule_loop(self) -> None:
        """Main scheduler loop."""
        while self.running:
            try:
                # Check if we should switch environment
                self._check_environment()
                
                # Wait for 5 minutes before checking again
                await asyncio.sleep(300)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}")
                await asyncio.sleep(60)  # Wait a bit before retrying

    def _check_environment(self) -> None:
        """Check if we should switch environment based on the schedule."""
        now = datetime.datetime.now(datetime.timezone.utc)
        current_day = now.weekday()  # 0=Monday, 6=Sunday
        current_hour = now.hour
        
        # Check if we should be in MAINNET
        mainnet_days = self.default_schedule.get("mainnet_days", [0, 1, 2, 3, 4])
        mainnet_start_hour = self.default_schedule.get("mainnet_start_hour", 8)
        mainnet_end_hour = self.default_schedule.get("mainnet_end_hour", 20)
        
        should_be_mainnet = (
            current_day in mainnet_days and
            mainnet_start_hour <= current_hour < mainnet_end_hour
        )
        
        # Switch environment if needed
        if should_be_mainnet and not self.env_manager.is_mainnet():
            logger.info(f"Scheduled switch to MAINNET (day={current_day}, hour={current_hour})")
            self.env_manager.switch_environment(Environment.MAINNET)
        elif not should_be_mainnet and not self.env_manager.is_testnet():
            logger.info(f"Scheduled switch to TESTNET (day={current_day}, hour={current_hour})")
            self.env_manager.switch_environment(Environment.TESTNET)
