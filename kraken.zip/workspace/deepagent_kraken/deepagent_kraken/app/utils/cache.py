"""
Caching utilities for the DeepAgent Kraken trading bot.
"""

import time
import logging
import functools
from typing import Any, Callable, Dict, Optional, Tuple, TypeVar, Union, cast
from functools import lru_cache
import asyncio

from app.utils.settings import CACHE_TTL, CACHE_MAX_SIZE, CACHE_ENABLED

logger = logging.getLogger(__name__)

# Type variables for better type hinting
T = TypeVar('T')
R = TypeVar('R')

# In-memory cache for storing data with expiration
_memory_cache: Dict[str, Tuple[float, Any]] = {}

def timed_lru_cache(
    seconds: int = CACHE_TTL, 
    maxsize: int = CACHE_MAX_SIZE, 
    typed: bool = False
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator that creates a timed LRU cache for the function.
    
    Args:
        seconds: Time to live (TTL) in seconds
        maxsize: Maximum size of the cache
        typed: Whether different types of arguments should be cached separately
        
    Returns:
        Decorated function with timed LRU cache
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        # Create a standard LRU cache
        func = lru_cache(maxsize=maxsize, typed=typed)(func)
        
        # Track the time when each cache entry was created
        func.lifetime = seconds
        func.expiration = time.time() + seconds
        
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            # Check if cache is enabled
            if not CACHE_ENABLED:
                return func(*args, **kwargs)
                
            # Check if cache has expired
            if time.time() > func.expiration:
                func.cache_clear()
                func.expiration = time.time() + func.lifetime
                
            return func(*args, **kwargs)
            
        wrapper.cache_info = func.cache_info  # type: ignore
        wrapper.cache_clear = func.cache_clear  # type: ignore
        
        return cast(Callable[..., T], wrapper)
        
    return decorator

def memoize(ttl: int = CACHE_TTL) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator that memoizes a function with a TTL.
    
    Args:
        ttl: Time to live (TTL) in seconds
        
    Returns:
        Decorated function with memoization
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            # Check if cache is enabled
            if not CACHE_ENABLED:
                return func(*args, **kwargs)
                
            # Create a cache key from the function name and arguments
            key = f"{func.__name__}:{str(args)}:{str(kwargs)}"
            
            # Check if the result is in the cache and not expired
            if key in _memory_cache:
                timestamp, result = _memory_cache[key]
                if time.time() - timestamp < ttl:
                    logger.debug(f"Cache hit for {key}")
                    return result
            
            # Call the function and cache the result
            result = func(*args, **kwargs)
            _memory_cache[key] = (time.time(), result)
            
            # Clean up expired cache entries
            _clean_cache()
            
            return result
            
        return wrapper
        
    return decorator

def async_memoize(ttl: int = CACHE_TTL) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator that memoizes an async function with a TTL.
    
    Args:
        ttl: Time to live (TTL) in seconds
        
    Returns:
        Decorated async function with memoization
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            # Check if cache is enabled
            if not CACHE_ENABLED:
                return await func(*args, **kwargs)
                
            # Create a cache key from the function name and arguments
            key = f"{func.__name__}:{str(args)}:{str(kwargs)}"
            
            # Check if the result is in the cache and not expired
            if key in _memory_cache:
                timestamp, result = _memory_cache[key]
                if time.time() - timestamp < ttl:
                    logger.debug(f"Cache hit for {key}")
                    return result
            
            # Call the function and cache the result
            result = await func(*args, **kwargs)
            _memory_cache[key] = (time.time(), result)
            
            # Clean up expired cache entries
            _clean_cache()
            
            return result
            
        return wrapper
        
    return decorator

def _clean_cache() -> None:
    """Clean up expired cache entries."""
    now = time.time()
    expired_keys = [
        key for key, (timestamp, _) in _memory_cache.items() 
        if now - timestamp > CACHE_TTL
    ]
    
    for key in expired_keys:
        del _memory_cache[key]
    
    # If cache is too large, remove oldest entries
    if len(_memory_cache) > CACHE_MAX_SIZE:
        sorted_items = sorted(_memory_cache.items(), key=lambda x: x[1][0])
        for key, _ in sorted_items[:len(_memory_cache) - CACHE_MAX_SIZE]:
            del _memory_cache[key]

def clear_cache() -> None:
    """Clear the entire cache."""
    _memory_cache.clear()
    logger.info("Cache cleared")

class AsyncLRUCache:
    """
    Asynchronous LRU cache implementation.
    """
    
    def __init__(self, maxsize: int = CACHE_MAX_SIZE, ttl: int = CACHE_TTL):
        """
        Initialize the async LRU cache.
        
        Args:
            maxsize: Maximum size of the cache
            ttl: Time to live (TTL) in seconds
        """
        self.maxsize = maxsize
        self.ttl = ttl
        self.cache: Dict[str, Tuple[float, Any]] = {}
        self.lock = asyncio.Lock()
        
    async def get(self, key: str) -> Optional[Any]:
        """
        Get a value from the cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found or expired
        """
        async with self.lock:
            if key in self.cache:
                timestamp, value = self.cache[key]
                if time.time() - timestamp < self.ttl:
                    # Move the item to the end to mark it as recently used
                    self.cache.pop(key)
                    self.cache[key] = (timestamp, value)
                    return value
                else:
                    # Remove expired item
                    self.cache.pop(key)
            return None
            
    async def set(self, key: str, value: Any) -> None:
        """
        Set a value in the cache.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        async with self.lock:
            # If cache is full, remove the oldest item
            if len(self.cache) >= self.maxsize:
                oldest_key = next(iter(self.cache))
                self.cache.pop(oldest_key)
                
            # Add the new item
            self.cache[key] = (time.time(), value)
            
    async def delete(self, key: str) -> None:
        """
        Delete a value from the cache.
        
        Args:
            key: Cache key
        """
        async with self.lock:
            if key in self.cache:
                self.cache.pop(key)
                
    async def clear(self) -> None:
        """Clear the entire cache."""
        async with self.lock:
            self.cache.clear()
            
    async def cleanup(self) -> None:
        """Clean up expired cache entries."""
        async with self.lock:
            now = time.time()
            expired_keys = [
                key for key, (timestamp, _) in self.cache.items() 
                if now - timestamp > self.ttl
            ]
            
            for key in expired_keys:
                self.cache.pop(key)

# Create a singleton instance of the async LRU cache
async_cache = AsyncLRUCache()
