"""
Rate limiter and connection pool manager for exchange API requests.
"""

import time
import logging
import asyncio
from typing import Dict, Optional, Callable, Any, TypeVar, cast
import functools
import aiohttp
from aiohttp import TCPConnector

from app.utils.settings import (
    RATE_LIMIT_BYBIT,
    RATE_LIMIT_OKX,
    RATE_LIMIT_BINANCE,
    CONNECTION_POOL_SIZE,
    CONNECTION_TIMEOUT,
    CONNECTION_KEEPALIVE_TIMEOUT
)

logger = logging.getLogger(__name__)

# Type variables for better type hinting
T = TypeVar('T')

class RateLimiter:
    """
    Rate limiter for API requests.
    """
    
    def __init__(self, max_rate: int, time_period: float = 1.0):
        """
        Initialize the rate limiter.
        
        Args:
            max_rate: Maximum number of requests per time period
            time_period: Time period in seconds
        """
        self.max_rate = max_rate
        self.time_period = time_period
        self.tokens = max_rate
        self.last_refill = time.time()
        self.lock = asyncio.Lock()
        
    async def acquire(self) -> None:
        """
        Acquire a token from the rate limiter.
        Blocks until a token is available.
        """
        async with self.lock:
            await self._refill()
            
            if self.tokens <= 0:
                # Calculate how long to wait for the next token
                wait_time = self.time_period / self.max_rate
                logger.debug(f"Rate limit reached, waiting {wait_time:.2f}s")
                await asyncio.sleep(wait_time)
                await self._refill()
                
            self.tokens -= 1
            
    async def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.time()
        elapsed = now - self.last_refill
        
        # Calculate how many tokens to add based on elapsed time
        new_tokens = elapsed * (self.max_rate / self.time_period)
        
        if new_tokens > 0:
            self.tokens = min(self.tokens + new_tokens, self.max_rate)
            self.last_refill = now

def rate_limited(
    exchange: str
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator that applies rate limiting to a function.
    
    Args:
        exchange: Exchange name to determine rate limit
        
    Returns:
        Decorated function with rate limiting
    """
    # Get the appropriate rate limit for the exchange
    if exchange.lower() == "bybit":
        rate_limit = RATE_LIMIT_BYBIT
    elif exchange.lower() == "okx":
        rate_limit = RATE_LIMIT_OKX
    elif exchange.lower() == "binance":
        rate_limit = RATE_LIMIT_BINANCE
    else:
        rate_limit = 5  # Default conservative limit
        
    # Create a rate limiter for this exchange
    limiter = RateLimiter(max_rate=rate_limit)
    
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> T:
            # Acquire a token from the rate limiter
            await limiter.acquire()
            
            # Call the function
            return await func(*args, **kwargs)
            
        return cast(Callable[..., T], wrapper)
        
    return decorator

class ConnectionManager:
    """
    Connection pool manager for HTTP requests.
    """
    
    _instance: Optional['ConnectionManager'] = None
    _initialized = False
    
    def __new__(cls) -> 'ConnectionManager':
        """Singleton pattern to ensure only one instance exists."""
        if cls._instance is None:
            cls._instance = super(ConnectionManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize the connection manager."""
        # Only initialize once
        if ConnectionManager._initialized:
            return
            
        self.session_pools: Dict[str, aiohttp.ClientSession] = {}
        ConnectionManager._initialized = True
        logger.info("Connection manager initialized")
        
    async def get_session(self, exchange: str) -> aiohttp.ClientSession:
        """
        Get or create a client session for the specified exchange.
        
        Args:
            exchange: Exchange name
            
        Returns:
            aiohttp ClientSession
        """
        if exchange not in self.session_pools:
            # Create a new session with a connection pool
            connector = TCPConnector(
                limit=CONNECTION_POOL_SIZE,
                ttl_dns_cache=300,
                keepalive_timeout=CONNECTION_KEEPALIVE_TIMEOUT
            )
            
            timeout = aiohttp.ClientTimeout(total=CONNECTION_TIMEOUT)
            
            self.session_pools[exchange] = aiohttp.ClientSession(
                connector=connector,
                timeout=timeout,
                headers={"User-Agent": "DeepAgent-Kraken-Bot/1.0"}
            )
            
            logger.info(f"Created new connection pool for {exchange}")
            
        return self.session_pools[exchange]
        
    async def close_all(self) -> None:
        """Close all client sessions."""
        for exchange, session in self.session_pools.items():
            if not session.closed:
                await session.close()
                logger.info(f"Closed connection pool for {exchange}")
                
        self.session_pools.clear()

# Create a singleton instance of the connection manager
connection_manager = ConnectionManager()
