"""
Global settings for the DeepAgent Kraken trading bot.
"""

# Cache settings
CACHE_ENABLED = True
CACHE_TTL = 300  # 5 minutes in seconds
CACHE_MAX_SIZE = 1000  # Maximum number of items in the cache

# Rate limiting settings
RATE_LIMIT_BYBIT = 10  # requests per second
RATE_LIMIT_OKX = 6  # requests per second
RATE_LIMIT_BINANCE = 10  # requests per second

# Connection pool settings
CONNECTION_POOL_SIZE = 100
CONNECTION_TIMEOUT = 30  # seconds
CONNECTION_KEEPALIVE_TIMEOUT = 60  # seconds

# Backtesting settings
BACKTEST_DEFAULT_TIMEFRAME = "1h"
BACKTEST_DEFAULT_START_DATE = "2023-01-01"
BACKTEST_DEFAULT_END_DATE = "2023-12-31"
BACKTEST_DEFAULT_INITIAL_CAPITAL = 10000  # USD
BACKTEST_DEFAULT_COMMISSION = 0.0004  # 0.04% taker fee
