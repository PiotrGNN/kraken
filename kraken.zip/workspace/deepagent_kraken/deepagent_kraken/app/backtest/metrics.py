"""
Performance metrics calculation for backtesting.
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime

logger = logging.getLogger(__name__)

def calculate_metrics(
    equity_curve: List[Dict[str, Any]],
    trades: List[Dict[str, Any]],
    initial_capital: float
) -> Dict[str, Any]:
    """
    Calculate performance metrics from backtest results.
    
    Args:
        equity_curve: List of equity points
        trades: List of trades
        initial_capital: Initial capital
        
    Returns:
        Dictionary of performance metrics
    """
    # Convert to DataFrame for easier calculations
    equity_df = pd.DataFrame(equity_curve)
    trades_df = pd.DataFrame(trades) if trades else pd.DataFrame()
    
    # Basic metrics
    final_equity = equity_df["equity"].iloc[-1] if not equity_df.empty else initial_capital
    total_return = (final_equity - initial_capital) / initial_capital
    total_return_pct = total_return * 100
    
    # Calculate trading period
    if len(equity_df) >= 2:
        start_date = equity_df["timestamp"].iloc[0]
        end_date = equity_df["timestamp"].iloc[-1]
        
        if isinstance(start_date, str):
            start_date = pd.to_datetime(start_date)
        if isinstance(end_date, str):
            end_date = pd.to_datetime(end_date)
            
        trading_days = (end_date - start_date).days
        trading_days = max(1, trading_days)  # Avoid division by zero
        years = trading_days / 365.25
    else:
        trading_days = 0
        years = 0
    
    # Annualized return
    annualized_return = (1 + total_return) ** (1 / years) - 1 if years > 0 else 0
    annualized_return_pct = annualized_return * 100
    
    # Maximum drawdown
    max_drawdown_pct = equity_df["drawdown_pct"].max() if not equity_df.empty else 0
    
    # Calculate daily returns
    if len(equity_df) >= 2:
        equity_df["daily_return"] = equity_df["equity"].pct_change()
        
        # Sharpe ratio (annualized)
        risk_free_rate = 0.02  # Assuming 2% risk-free rate
        excess_returns = equity_df["daily_return"] - (risk_free_rate / 252)  # Daily risk-free rate
        sharpe_ratio = np.sqrt(252) * excess_returns.mean() / excess_returns.std() if excess_returns.std() > 0 else 0
        
        # Sortino ratio (annualized)
        downside_returns = equity_df["daily_return"].copy()
        downside_returns[downside_returns > 0] = 0
        sortino_ratio = np.sqrt(252) * excess_returns.mean() / downside_returns.std() if downside_returns.std() > 0 else 0
        
        # Calmar ratio (annualized return / max drawdown)
        calmar_ratio = annualized_return / (max_drawdown_pct / 100) if max_drawdown_pct > 0 else 0
    else:
        sharpe_ratio = 0
        sortino_ratio = 0
        calmar_ratio = 0
    
    # Trade metrics
    if not trades_df.empty and "profit" in trades_df.columns:
        total_trades = len(trades_df)
        profitable_trades = len(trades_df[trades_df["profit"] > 0])
        losing_trades = len(trades_df[trades_df["profit"] <= 0])
        win_rate = profitable_trades / total_trades if total_trades > 0 else 0
        
        # Average profit/loss
        avg_profit = trades_df[trades_df["profit"] > 0]["profit"].mean() if profitable_trades > 0 else 0
        avg_loss = trades_df[trades_df["profit"] <= 0]["profit"].mean() if losing_trades > 0 else 0
        
        # Profit factor
        gross_profit = trades_df[trades_df["profit"] > 0]["profit"].sum() if profitable_trades > 0 else 0
        gross_loss = abs(trades_df[trades_df["profit"] <= 0]["profit"].sum()) if losing_trades > 0 else 0
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf') if gross_profit > 0 else 0
        
        # Expectancy
        expectancy = (win_rate * avg_profit) + ((1 - win_rate) * avg_loss) if total_trades > 0 else 0
        
        # Average trade duration
        if "timestamp" in trades_df.columns and len(trades_df) >= 2:
            trades_df["timestamp"] = pd.to_datetime(trades_df["timestamp"])
            trade_durations = []
            
            for i in range(1, len(trades_df)):
                if trades_df["action"].iloc[i-1].startswith("open") and trades_df["action"].iloc[i].startswith("close"):
                    duration = (trades_df["timestamp"].iloc[i] - trades_df["timestamp"].iloc[i-1]).total_seconds() / 3600  # hours
                    trade_durations.append(duration)
                    
            avg_trade_duration = np.mean(trade_durations) if trade_durations else 0
        else:
            avg_trade_duration = 0
    else:
        total_trades = 0
        profitable_trades = 0
        losing_trades = 0
        win_rate = 0
        avg_profit = 0
        avg_loss = 0
        profit_factor = 0
        expectancy = 0
        avg_trade_duration = 0
    
    # Compile all metrics
    metrics = {
        "total_return": total_return,
        "total_return_pct": total_return_pct,
        "annualized_return": annualized_return,
        "annualized_return_pct": annualized_return_pct,
        "sharpe_ratio": sharpe_ratio,
        "sortino_ratio": sortino_ratio,
        "calmar_ratio": calmar_ratio,
        "max_drawdown_pct": max_drawdown_pct,
        "trading_days": trading_days,
        "total_trades": total_trades,
        "profitable_trades": profitable_trades,
        "losing_trades": losing_trades,
        "win_rate": win_rate,
        "avg_profit": avg_profit,
        "avg_loss": avg_loss,
        "profit_factor": profit_factor,
        "expectancy": expectancy,
        "avg_trade_duration_hours": avg_trade_duration
    }
    
    return metrics

def calculate_drawdowns(equity_series: pd.Series) -> Tuple[float, List[Dict[str, Any]]]:
    """
    Calculate drawdowns from an equity curve.
    
    Args:
        equity_series: Series of equity values
        
    Returns:
        Tuple of (max_drawdown_pct, list_of_drawdowns)
    """
    # Calculate running maximum
    running_max = equity_series.cummax()
    
    # Calculate drawdown in percentage terms
    drawdown = (running_max - equity_series) / running_max * 100
    
    # Find drawdown periods
    is_drawdown = drawdown > 0
    
    # Initialize variables for tracking drawdown periods
    drawdown_periods = []
    current_drawdown = None
    
    # Iterate through the series
    for i, (date, dd_pct) in enumerate(drawdown.items()):
        if dd_pct > 0:
            # In a drawdown
            if current_drawdown is None:
                # Start of a new drawdown
                current_drawdown = {
                    "start_date": date,
                    "start_equity": running_max[i],
                    "max_drawdown_pct": dd_pct
                }
            else:
                # Update maximum drawdown if needed
                current_drawdown["max_drawdown_pct"] = max(current_drawdown["max_drawdown_pct"], dd_pct)
        elif current_drawdown is not None:
            # End of a drawdown
            current_drawdown["end_date"] = date
            current_drawdown["end_equity"] = equity_series[i]
            current_drawdown["duration_days"] = (current_drawdown["end_date"] - current_drawdown["start_date"]).days
            
            drawdown_periods.append(current_drawdown)
            current_drawdown = None
    
    # Handle case where we're still in a drawdown at the end
    if current_drawdown is not None:
        current_drawdown["end_date"] = equity_series.index[-1]
        current_drawdown["end_equity"] = equity_series.iloc[-1]
        current_drawdown["duration_days"] = (current_drawdown["end_date"] - current_drawdown["start_date"]).days
        
        drawdown_periods.append(current_drawdown)
    
    # Sort drawdowns by magnitude
    drawdown_periods.sort(key=lambda x: x["max_drawdown_pct"], reverse=True)
    
    # Get maximum drawdown percentage
    max_drawdown_pct = drawdown.max()
    
    return max_drawdown_pct, drawdown_periods

def calculate_monthly_returns(equity_curve: List[Dict[str, Any]]) -> Dict[str, float]:
    """
    Calculate monthly returns from an equity curve.
    
    Args:
        equity_curve: List of equity points
        
    Returns:
        Dictionary of monthly returns
    """
    # Convert to DataFrame
    equity_df = pd.DataFrame(equity_curve)
    
    # Ensure timestamp is datetime
    equity_df["timestamp"] = pd.to_datetime(equity_df["timestamp"])
    
    # Set timestamp as index
    equity_df.set_index("timestamp", inplace=True)
    
    # Resample to get month-end values
    monthly_equity = equity_df["equity"].resample("M").last()
    
    # Calculate monthly returns
    monthly_returns = monthly_equity.pct_change().dropna()
    
    # Convert to dictionary
    return {date.strftime("%Y-%m"): return_val for date, return_val in monthly_returns.items()}

def calculate_rolling_returns(
    equity_curve: List[Dict[str, Any]], 
    window_days: int = 30
) -> pd.Series:
    """
    Calculate rolling returns over a specified window.
    
    Args:
        equity_curve: List of equity points
        window_days: Rolling window size in days
        
    Returns:
        Series of rolling returns
    """
    # Convert to DataFrame
    equity_df = pd.DataFrame(equity_curve)
    
    # Ensure timestamp is datetime
    equity_df["timestamp"] = pd.to_datetime(equity_df["timestamp"])
    
    # Set timestamp as index
    equity_df.set_index("timestamp", inplace=True)
    
    # Calculate rolling returns
    rolling_returns = equity_df["equity"].pct_change(window_days).dropna()
    
    return rolling_returns
