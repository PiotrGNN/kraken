"""
Strategy optimizer for backtesting.
"""

import logging
import pandas as pd
import numpy as np
import asyncio
import itertools
import multiprocessing
from typing import Dict, List, Any, Optional, Tuple, Union, Callable
import time
import json
import os
from concurrent.futures import ProcessPoolExecutor

from app.backtest.engine import BacktestEngine
from app.utils.settings import (
    BACKTEST_DEFAULT_TIMEFRAME,
    BACKTEST_DEFAULT_INITIAL_CAPITAL,
    BACKTEST_DEFAULT_COMMISSION
)

logger = logging.getLogger(__name__)

class StrategyOptimizer:
    """
    Optimizer for trading strategy parameters.
    """
    
    def __init__(self, 
                data: pd.DataFrame,
                symbol: str = "BTCUSDT",
                timeframe: str = BACKTEST_DEFAULT_TIMEFRAME,
                initial_capital: float = BACKTEST_DEFAULT_INITIAL_CAPITAL,
                commission_rate: float = BACKTEST_DEFAULT_COMMISSION,
                base_strategy_config: Optional[Dict[str, Any]] = None,
                base_risk_config: Optional[Dict[str, Any]] = None,
                optimization_metric: str = "sharpe_ratio"):
        """
        Initialize the strategy optimizer.
        
        Args:
            data: Historical price data
            symbol: Trading pair symbol
            timeframe: Timeframe interval
            initial_capital: Initial capital
            commission_rate: Commission rate
            base_strategy_config: Base strategy configuration
            base_risk_config: Base risk management configuration
            optimization_metric: Metric to optimize (e.g., sharpe_ratio, total_return)
        """
        self.data = data
        self.symbol = symbol
        self.timeframe = timeframe
        self.initial_capital = initial_capital
        self.commission_rate = commission_rate
        self.base_strategy_config = base_strategy_config or {}
        self.base_risk_config = base_risk_config or {}
        self.optimization_metric = optimization_metric
        
        # Set default symbol and timeframe in base configs
        self.base_strategy_config["symbol"] = symbol
        self.base_strategy_config["timeframe"] = timeframe
        
        # Results storage
        self.optimization_results = []
        
    async def optimize_grid_search(self, 
                                 param_grid: Dict[str, List[Any]],
                                 config_type: str = "strategy",
                                 max_workers: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Perform grid search optimization.
        
        Args:
            param_grid: Dictionary of parameters to optimize and their possible values
            config_type: Type of configuration to optimize ("strategy" or "risk")
            max_workers: Maximum number of parallel workers (default: number of CPU cores)
            
        Returns:
            List of optimization results
        """
        # Generate all parameter combinations
        param_keys = list(param_grid.keys())
        param_values = list(param_grid.values())
        param_combinations = list(itertools.product(*param_values))
        
        logger.info(f"Starting grid search with {len(param_combinations)} parameter combinations")
        
        # Determine number of workers
        if max_workers is None:
            max_workers = multiprocessing.cpu_count()
        
        # Create tasks for each parameter combination
        tasks = []
        for combination in param_combinations:
            # Create parameter dictionary
            params = dict(zip(param_keys, combination))
            
            # Create configuration
            if config_type == "strategy":
                strategy_config = {**self.base_strategy_config, **params}
                risk_config = self.base_risk_config.copy()
            else:  # risk
                strategy_config = self.base_strategy_config.copy()
                risk_config = {**self.base_risk_config, **params}
                
            # Create task
            task = self._run_backtest(strategy_config, risk_config)
            tasks.append(task)
            
        # Run tasks with semaphore to limit concurrency
        semaphore = asyncio.Semaphore(max_workers)
        
        async def run_with_semaphore(task):
            async with semaphore:
                return await task
                
        # Execute all tasks
        results = await asyncio.gather(*[run_with_semaphore(task) for task in tasks])
        
        # Sort results by optimization metric
        self.optimization_results = sorted(
            results, 
            key=lambda x: x["metrics"].get(self.optimization_metric, 0), 
            reverse=True
        )
        
        logger.info(f"Grid search completed with {len(self.optimization_results)} results")
        
        return self.optimization_results
        
    async def optimize_random_search(self, 
                                   param_ranges: Dict[str, Tuple[Any, Any]],
                                   param_types: Dict[str, str],
                                   num_trials: int = 100,
                                   config_type: str = "strategy",
                                   max_workers: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Perform random search optimization.
        
        Args:
            param_ranges: Dictionary of parameters to optimize and their ranges (min, max)
            param_types: Dictionary of parameter types ("int", "float", "categorical")
            num_trials: Number of random trials
            config_type: Type of configuration to optimize ("strategy" or "risk")
            max_workers: Maximum number of parallel workers (default: number of CPU cores)
            
        Returns:
            List of optimization results
        """
        logger.info(f"Starting random search with {num_trials} trials")
        
        # Determine number of workers
        if max_workers is None:
            max_workers = multiprocessing.cpu_count()
        
        # Create tasks for each random trial
        tasks = []
        for _ in range(num_trials):
            # Generate random parameters
            params = {}
            for param_name, param_range in param_ranges.items():
                param_type = param_types.get(param_name, "float")
                
                if param_type == "int":
                    params[param_name] = np.random.randint(param_range[0], param_range[1] + 1)
                elif param_type == "float":
                    params[param_name] = np.random.uniform(param_range[0], param_range[1])
                elif param_type == "categorical":
                    params[param_name] = np.random.choice(param_range)
                    
            # Create configuration
            if config_type == "strategy":
                strategy_config = {**self.base_strategy_config, **params}
                risk_config = self.base_risk_config.copy()
            else:  # risk
                strategy_config = self.base_strategy_config.copy()
                risk_config = {**self.base_risk_config, **params}
                
            # Create task
            task = self._run_backtest(strategy_config, risk_config)
            tasks.append(task)
            
        # Run tasks with semaphore to limit concurrency
        semaphore = asyncio.Semaphore(max_workers)
        
        async def run_with_semaphore(task):
            async with semaphore:
                return await task
                
        # Execute all tasks
        results = await asyncio.gather(*[run_with_semaphore(task) for task in tasks])
        
        # Sort results by optimization metric
        self.optimization_results = sorted(
            results, 
            key=lambda x: x["metrics"].get(self.optimization_metric, 0), 
            reverse=True
        )
        
        logger.info(f"Random search completed with {len(self.optimization_results)} results")
        
        return self.optimization_results
        
    async def _run_backtest(self, 
                          strategy_config: Dict[str, Any], 
                          risk_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run a single backtest with the given parameters.
        
        Args:
            strategy_config: Strategy configuration
            risk_config: Risk management configuration
            
        Returns:
            Backtest results
        """
        # Create backtest engine
        engine = BacktestEngine(
            data=self.data,
            symbol=self.symbol,
            timeframe=self.timeframe,
            initial_capital=self.initial_capital,
            commission_rate=self.commission_rate,
            strategy_config=strategy_config,
            risk_config=risk_config
        )
        
        # Run backtest
        results = await engine.run()
        
        # Add parameter values to results
        results["parameters"] = {
            "strategy": strategy_config,
            "risk": risk_config
        }
        
        return results
        
    def save_results(self, output_dir: str = "optimization_results", top_n: int = 10) -> str:
        """
        Save optimization results to files.
        
        Args:
            output_dir: Output directory
            top_n: Number of top results to save
            
        Returns:
            Path to the results directory
        """
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate timestamp for unique filenames
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        
        # Create a subdirectory for this optimization
        opt_dir = os.path.join(output_dir, f"{self.symbol}_{self.timeframe}_{timestamp}")
        os.makedirs(opt_dir, exist_ok=True)
        
        # Save top N results
        top_results = self.optimization_results[:top_n]
        
        # Save summary to CSV
        summary_rows = []
        for i, result in enumerate(top_results):
            row = {
                "rank": i + 1,
                "final_equity": result["final_equity"],
                "total_return_pct": result["metrics"]["total_return_pct"],
                "sharpe_ratio": result["metrics"]["sharpe_ratio"],
                "max_drawdown_pct": result["metrics"]["max_drawdown_pct"],
                "win_rate": result["metrics"]["win_rate"],
                "profit_factor": result["metrics"]["profit_factor"]
            }
            
            # Add parameters
            for param_type, params in result["parameters"].items():
                for param_name, param_value in params.items():
                    if param_name not in ["symbol", "timeframe"]:
                        row[f"{param_type}_{param_name}"] = param_value
                        
            summary_rows.append(row)
            
        summary_df = pd.DataFrame(summary_rows)
        summary_df.to_csv(os.path.join(opt_dir, "optimization_summary.csv"), index=False)
        
        # Save detailed results for each top result
        for i, result in enumerate(top_results):
            result_dir = os.path.join(opt_dir, f"rank_{i+1}")
            os.makedirs(result_dir, exist_ok=True)
            
            # Save equity curve
            equity_df = pd.DataFrame(result["equity_curve"])
            equity_df.to_csv(os.path.join(result_dir, "equity_curve.csv"), index=False)
            
            # Save trades
            trades_df = pd.DataFrame(result["trades"])
            if not trades_df.empty:
                trades_df.to_csv(os.path.join(result_dir, "trades.csv"), index=False)
            
            # Save metrics
            with open(os.path.join(result_dir, "metrics.json"), "w") as f:
                json.dump(result["metrics"], f, indent=4)
                
            # Save parameters
            with open(os.path.join(result_dir, "parameters.json"), "w") as f:
                json.dump(result["parameters"], f, indent=4)
                
            # Generate plots
            try:
                from app.backtest.plot import create_equity_chart, create_drawdown_chart
                
                # Create equity chart
                equity_chart_path = os.path.join(result_dir, "equity_chart.html")
                create_equity_chart(result["equity_curve"], result["trades"], equity_chart_path)
                
                # Create drawdown chart
                drawdown_chart_path = os.path.join(result_dir, "drawdown_chart.html")
                create_drawdown_chart(result["equity_curve"], drawdown_chart_path)
                
            except Exception as e:
                logger.error(f"Error generating plots: {e}")
                
        # Save optimization configuration
        config = {
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "initial_capital": self.initial_capital,
            "commission_rate": self.commission_rate,
            "base_strategy_config": self.base_strategy_config,
            "base_risk_config": self.base_risk_config,
            "optimization_metric": self.optimization_metric,
            "num_combinations": len(self.optimization_results)
        }
        with open(os.path.join(opt_dir, "optimization_config.json"), "w") as f:
            json.dump(config, f, indent=4)
            
        logger.info(f"Optimization results saved to {opt_dir}")
        
        return opt_dir
