"""
Backtesting engine for the DeepAgent Kraken trading bot.
"""

import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union, Callable
import os
import json

from app.strategies.trend_follower import TrendFollowerStrategy
from app.risk.atr_risk import ATRRiskManager
from app.utils.settings import (
    BACKTEST_DEFAULT_TIMEFRAME,
    BACKTEST_DEFAULT_START_DATE,
    BACKTEST_DEFAULT_END_DATE,
    BACKTEST_DEFAULT_INITIAL_CAPITAL,
    BACKTEST_DEFAULT_COMMISSION
)

logger = logging.getLogger(__name__)

class MockOrderRouter:
    """
    Mock order router for backtesting.
    Simulates the behavior of the real OrderRouter without making API calls.
    """
    
    def __init__(self, data: pd.DataFrame, commission_rate: float = BACKTEST_DEFAULT_COMMISSION):
        """
        Initialize the mock order router.
        
        Args:
            data: Historical price data
            commission_rate: Commission rate (e.g., 0.0004 for 0.04%)
        """
        self.data = data
        self.commission_rate = commission_rate
        self.current_index = 0
        self.positions = {}
        self.orders = {}
        self.order_id_counter = 1
        self.account_balance = {
            "equity": BACKTEST_DEFAULT_INITIAL_CAPITAL,
            "available_balance": BACKTEST_DEFAULT_INITIAL_CAPITAL,
            "used_margin": 0.0
        }
        
    async def get_klines(self, symbol: str, interval: str, limit: int = 300) -> List[Dict[str, Any]]:
        """
        Get historical klines data.
        
        Args:
            symbol: Trading pair symbol
            interval: Timeframe interval
            limit: Number of candles to return
            
        Returns:
            List of klines data
        """
        # Get data up to the current index
        end_idx = self.current_index + 1
        start_idx = max(0, end_idx - limit)
        
        # Extract the relevant slice of data
        df_slice = self.data.iloc[start_idx:end_idx].copy()
        
        # Convert to the format expected by the strategy
        klines = []
        for _, row in df_slice.iterrows():
            kline = {
                "open_time": row.name.timestamp() * 1000 if isinstance(row.name, pd.Timestamp) else row.name,
                "open": row["open"],
                "high": row["high"],
                "low": row["low"],
                "close": row["close"],
                "volume": row["volume"] if "volume" in row else 0
            }
            klines.append(kline)
            
        return klines
        
    async def place_order(self, symbol: str, side: str, order_type: str, 
                         quantity: float, price: Optional[float] = None, 
                         stop_price: Optional[float] = None, 
                         time_in_force: str = "GTC", 
                         reduce_only: bool = False,
                         **kwargs) -> Dict[str, Any]:
        """
        Place a simulated order.
        
        Args:
            symbol: Trading pair symbol
            side: Order side (buy/sell)
            order_type: Type of order
            quantity: Order quantity
            price: Order price (for limit orders)
            stop_price: Stop price (for stop orders)
            time_in_force: Time in force
            reduce_only: Whether the order should only reduce position
            **kwargs: Additional parameters
            
        Returns:
            Order details
        """
        # Get current price from the data
        current_row = self.data.iloc[self.current_index]
        current_price = current_row["close"]
        
        # Generate a unique order ID
        order_id = str(self.order_id_counter)
        self.order_id_counter += 1
        
        # Calculate execution price based on order type
        execution_price = current_price
        if order_type == "limit" and price is not None:
            execution_price = price
        elif order_type == "stop_market" and stop_price is not None:
            execution_price = stop_price
            
        # Calculate commission
        commission = quantity * execution_price * self.commission_rate
        
        # Create order object
        order = {
            "order_id": order_id,
            "symbol": symbol,
            "side": side,
            "order_type": order_type,
            "quantity": quantity,
            "price": price,
            "stop_price": stop_price,
            "execution_price": execution_price,
            "time_in_force": time_in_force,
            "reduce_only": reduce_only,
            "status": "FILLED" if order_type != "stop_market" else "NEW",
            "commission": commission,
            "created_time": current_row.name.timestamp() if isinstance(current_row.name, pd.Timestamp) else current_row.name,
            "filled_time": current_row.name.timestamp() if isinstance(current_row.name, pd.Timestamp) else current_row.name if order_type != "stop_market" else None
        }
        
        # Store the order
        self.orders[order_id] = order
        
        # Update position if the order is filled immediately (market orders)
        if order_type == "market" or (order_type == "limit" and price is not None and 
                                     ((side == "buy" and price >= current_price) or 
                                      (side == "sell" and price <= current_price))):
            self._update_position(symbol, side, quantity, execution_price, commission)
            
        return order
        
    async def cancel_order(self, order_id: str, symbol: str) -> Dict[str, Any]:
        """
        Cancel a simulated order.
        
        Args:
            order_id: Order ID
            symbol: Trading pair symbol
            
        Returns:
            Cancellation result
        """
        if order_id in self.orders:
            order = self.orders[order_id]
            if order["status"] == "NEW":
                order["status"] = "CANCELED"
                
            return {"order_id": order_id, "status": "CANCELED"}
        else:
            return {"order_id": order_id, "status": "NOT_FOUND"}
            
    async def get_position(self, symbol: str) -> Dict[str, Any]:
        """
        Get current position.
        
        Args:
            symbol: Trading pair symbol
            
        Returns:
            Position details
        """
        if symbol in self.positions:
            position = self.positions[symbol].copy()
            
            # Calculate unrealized PnL based on current price
            current_price = self.data.iloc[self.current_index]["close"]
            entry_price = position["entry_price"]
            size = position["size"]
            
            if size > 0:  # Long position
                unrealized_pnl = (current_price - entry_price) * size
            elif size < 0:  # Short position
                unrealized_pnl = (entry_price - current_price) * abs(size)
            else:
                unrealized_pnl = 0
                
            position["unrealized_pnl"] = unrealized_pnl
            position["mark_price"] = current_price
            
            return position
        else:
            # Return empty position
            return {
                "symbol": symbol,
                "size": 0,
                "entry_price": 0,
                "mark_price": self.data.iloc[self.current_index]["close"],
                "unrealized_pnl": 0
            }
            
    async def get_account_balance(self) -> Dict[str, float]:
        """
        Get account balance.
        
        Returns:
            Account balance details
        """
        # Calculate total equity including unrealized PnL
        total_unrealized_pnl = 0
        for symbol, position in self.positions.items():
            current_price = self.data.iloc[self.current_index]["close"]
            entry_price = position["entry_price"]
            size = position["size"]
            
            if size > 0:  # Long position
                unrealized_pnl = (current_price - entry_price) * size
            elif size < 0:  # Short position
                unrealized_pnl = (entry_price - current_price) * abs(size)
            else:
                unrealized_pnl = 0
                
            total_unrealized_pnl += unrealized_pnl
            
        equity = self.account_balance["available_balance"] + total_unrealized_pnl
        
        return {
            "equity": equity,
            "available_balance": self.account_balance["available_balance"],
            "used_margin": self.account_balance["used_margin"],
            "unrealized_pnl": total_unrealized_pnl
        }
        
    async def get_ticker(self, symbol: str) -> Dict[str, float]:
        """
        Get ticker data.
        
        Args:
            symbol: Trading pair symbol
            
        Returns:
            Ticker data
        """
        current_row = self.data.iloc[self.current_index]
        
        return {
            "symbol": symbol,
            "last_price": current_row["close"],
            "bid_price": current_row["close"] * 0.9999,  # Simulate a small spread
            "ask_price": current_row["close"] * 1.0001,
            "volume": current_row["volume"] if "volume" in current_row else 0
        }
        
    def _update_position(self, symbol: str, side: str, quantity: float, 
                        price: float, commission: float) -> None:
        """
        Update position after an order is filled.
        
        Args:
            symbol: Trading pair symbol
            side: Order side (buy/sell)
            quantity: Order quantity
            price: Execution price
            commission: Commission paid
        """
        # Get current position
        position = self.positions.get(symbol, {
            "symbol": symbol,
            "size": 0,
            "entry_price": 0,
            "unrealized_pnl": 0
        })
        
        current_size = position.get("size", 0)
        current_entry_price = position.get("entry_price", 0)
        
        # Calculate new position
        if side == "buy":
            # Calculate realized PnL if reducing a short position
            realized_pnl = 0
            if current_size < 0 and abs(current_size) >= quantity:
                # Reducing short position
                realized_pnl = (current_entry_price - price) * quantity
            
            # Update position size
            new_size = current_size + quantity
            
            # Calculate new entry price if increasing position
            if current_size >= 0:
                # Increasing long position or opening new long
                new_entry_price = ((current_size * current_entry_price) + (quantity * price)) / (current_size + quantity) if new_size > 0 else 0
            else:
                # Reducing short position
                new_entry_price = current_entry_price if new_size < 0 else 0
                
        else:  # sell
            # Calculate realized PnL if reducing a long position
            realized_pnl = 0
            if current_size > 0 and current_size >= quantity:
                # Reducing long position
                realized_pnl = (price - current_entry_price) * quantity
            
            # Update position size
            new_size = current_size - quantity
            
            # Calculate new entry price if increasing position
            if current_size <= 0:
                # Increasing short position or opening new short
                new_entry_price = ((abs(current_size) * current_entry_price) + (quantity * price)) / (abs(current_size) + quantity) if new_size < 0 else 0
            else:
                # Reducing long position
                new_entry_price = current_entry_price if new_size > 0 else 0
        
        # Update position
        self.positions[symbol] = {
            "symbol": symbol,
            "size": new_size,
            "entry_price": new_entry_price,
            "unrealized_pnl": 0  # Will be calculated when get_position is called
        }
        
        # Update account balance
        self.account_balance["available_balance"] -= commission
        if realized_pnl != 0:
            self.account_balance["available_balance"] += realized_pnl
            
    def advance_to_next_candle(self) -> None:
        """Advance to the next candle in the dataset."""
        self.current_index += 1
        
        # Process any pending stop orders
        self._process_pending_stop_orders()
        
    def _process_pending_stop_orders(self) -> None:
        """Process any pending stop orders based on the current price."""
        if self.current_index >= len(self.data):
            return
            
        current_row = self.data.iloc[self.current_index]
        current_high = current_row["high"]
        current_low = current_row["low"]
        
        # Check all pending stop orders
        for order_id, order in list(self.orders.items()):
            if order["status"] != "NEW" or order["order_type"] != "stop_market":
                continue
                
            stop_price = order["stop_price"]
            if stop_price is None:
                continue
                
            # Check if stop price was hit
            if (order["side"] == "buy" and current_low <= stop_price <= current_high) or \
               (order["side"] == "sell" and current_low <= stop_price <= current_high):
                # Stop order triggered
                order["status"] = "FILLED"
                order["filled_time"] = current_row.name.timestamp() if isinstance(current_row.name, pd.Timestamp) else current_row.name
                
                # Update position
                self._update_position(
                    symbol=order["symbol"],
                    side=order["side"],
                    quantity=order["quantity"],
                    price=stop_price,
                    commission=order["commission"]
                )

class BacktestEngine:
    """
    Backtesting engine for the DeepAgent Kraken trading bot.
    """
    
    def __init__(self, 
                data: pd.DataFrame,
                symbol: str = "BTCUSDT",
                timeframe: str = BACKTEST_DEFAULT_TIMEFRAME,
                initial_capital: float = BACKTEST_DEFAULT_INITIAL_CAPITAL,
                commission_rate: float = BACKTEST_DEFAULT_COMMISSION,
                strategy_config: Optional[Dict[str, Any]] = None,
                risk_config: Optional[Dict[str, Any]] = None):
        """
        Initialize the backtesting engine.
        
        Args:
            data: Historical price data
            symbol: Trading pair symbol
            timeframe: Timeframe interval
            initial_capital: Initial capital
            commission_rate: Commission rate
            strategy_config: Strategy configuration
            risk_config: Risk management configuration
        """
        self.data = data
        self.symbol = symbol
        self.timeframe = timeframe
        self.initial_capital = initial_capital
        self.commission_rate = commission_rate
        
        # Ensure data has the required columns
        required_columns = ['open', 'high', 'low', 'close']
        if not all(col in data.columns for col in required_columns):
            raise ValueError(f"Data must contain columns: {required_columns}")
            
        # Create mock order router
        self.order_router = MockOrderRouter(data, commission_rate)
        
        # Create risk manager
        self.risk_config = risk_config or {}
        self.risk_manager = ATRRiskManager(self.risk_config)
        
        # Create strategy
        self.strategy_config = strategy_config or {}
        self.strategy_config["symbol"] = symbol
        self.strategy_config["timeframe"] = timeframe
        
        # Results storage
        self.equity_curve = []
        self.trades = []
        self.metrics = {}
        
    async def run(self) -> Dict[str, Any]:
        """
        Run the backtest.
        
        Returns:
            Backtest results
        """
        logger.info(f"Starting backtest for {self.symbol} on {self.timeframe} timeframe")
        
        # Create strategy instance
        strategy = TrendFollowerStrategy(self.order_router, self.risk_manager, self.strategy_config)
        
        # Initialize equity curve with initial capital
        self.equity_curve = [{
            "timestamp": self.data.index[0],
            "equity": self.initial_capital,
            "drawdown_pct": 0.0
        }]
        
        # Track highest equity for drawdown calculation
        highest_equity = self.initial_capital
        
        # Iterate through each candle
        for i in range(len(self.data)):
            # Set current index in the mock order router
            self.order_router.current_index = i
            
            # Execute strategy
            try:
                result = await strategy.execute_strategy()
                
                # Record trade if one was made
                if result.get("action") not in ["no_action", "hold_long", "hold_short"]:
                    trade = {
                        "timestamp": self.data.index[i],
                        "action": result.get("action"),
                        "price": result.get("price", self.data.iloc[i]["close"]),
                        "size": result.get("size", 0),
                        "profit": result.get("profit", 0)
                    }
                    self.trades.append(trade)
                
                # Get account balance
                account = await self.order_router.get_account_balance()
                equity = account["equity"]
                
                # Calculate drawdown
                highest_equity = max(highest_equity, equity)
                drawdown_pct = (highest_equity - equity) / highest_equity * 100 if highest_equity > 0 else 0
                
                # Record equity
                self.equity_curve.append({
                    "timestamp": self.data.index[i],
                    "equity": equity,
                    "drawdown_pct": drawdown_pct
                })
                
            except Exception as e:
                logger.error(f"Error executing strategy at {self.data.index[i]}: {e}")
                
            # Advance to next candle
            if i < len(self.data) - 1:
                self.order_router.advance_to_next_candle()
                
        # Calculate performance metrics
        from app.backtest.metrics import calculate_metrics
        self.metrics = calculate_metrics(self.equity_curve, self.trades, self.initial_capital)
        
        logger.info(f"Backtest completed with final equity: ${self.equity_curve[-1]['equity']:.2f}")
        
        return {
            "equity_curve": self.equity_curve,
            "trades": self.trades,
            "metrics": self.metrics,
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "initial_capital": self.initial_capital,
            "final_equity": self.equity_curve[-1]["equity"],
            "strategy_config": self.strategy_config,
            "risk_config": self.risk_config
        }
        
    def save_results(self, output_dir: str = "backtest_results") -> str:
        """
        Save backtest results to files.
        
        Args:
            output_dir: Output directory
            
        Returns:
            Path to the results directory
        """
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate timestamp for unique filenames
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create a subdirectory for this backtest
        backtest_dir = os.path.join(output_dir, f"{self.symbol}_{self.timeframe}_{timestamp}")
        os.makedirs(backtest_dir, exist_ok=True)
        
        # Save equity curve to CSV
        equity_df = pd.DataFrame(self.equity_curve)
        equity_df.to_csv(os.path.join(backtest_dir, "equity_curve.csv"), index=False)
        
        # Save trades to CSV
        trades_df = pd.DataFrame(self.trades)
        if not trades_df.empty:
            trades_df.to_csv(os.path.join(backtest_dir, "trades.csv"), index=False)
        
        # Save metrics to JSON
        with open(os.path.join(backtest_dir, "metrics.json"), "w") as f:
            json.dump(self.metrics, f, indent=4)
            
        # Save configuration to JSON
        config = {
            "symbol": self.symbol,
            "timeframe": self.timeframe,
            "initial_capital": self.initial_capital,
            "commission_rate": self.commission_rate,
            "strategy_config": self.strategy_config,
            "risk_config": self.risk_config
        }
        with open(os.path.join(backtest_dir, "config.json"), "w") as f:
            json.dump(config, f, indent=4)
            
        # Generate plots
        try:
            from app.backtest.plot import create_equity_chart, create_drawdown_chart
            
            # Create equity chart
            equity_chart_path = os.path.join(backtest_dir, "equity_chart.html")
            create_equity_chart(self.equity_curve, self.trades, equity_chart_path)
            
            # Create drawdown chart
            drawdown_chart_path = os.path.join(backtest_dir, "drawdown_chart.html")
            create_drawdown_chart(self.equity_curve, drawdown_chart_path)
            
        except Exception as e:
            logger.error(f"Error generating plots: {e}")
            
        logger.info(f"Backtest results saved to {backtest_dir}")
        
        return backtest_dir
