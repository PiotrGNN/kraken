"""
Backtesting module for the DeepAgent Kraken trading bot.
"""

from app.backtest.engine import BacktestEngine
from app.backtest.metrics import calculate_metrics
from app.backtest.optimizer import StrategyOptimizer
from app.backtest.plot import create_equity_chart, create_drawdown_chart

__all__ = [
    'BacktestEngine',
    'calculate_metrics',
    'StrategyOptimizer',
    'create_equity_chart',
    'create_drawdown_chart'
]
