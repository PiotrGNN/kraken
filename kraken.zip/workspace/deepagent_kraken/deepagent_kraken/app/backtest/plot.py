"""
Visualization tools for backtesting results.
"""

import logging
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os

logger = logging.getLogger(__name__)

def create_equity_chart(
    equity_curve: List[Dict[str, Any]],
    trades: List[Dict[str, Any]],
    output_path: Optional[str] = None
) -> go.Figure:
    """
    Create an equity curve chart with trade markers.
    
    Args:
        equity_curve: List of equity points
        trades: List of trades
        output_path: Path to save the chart (optional)
        
    Returns:
        Plotly figure
    """
    # Convert to DataFrame
    equity_df = pd.DataFrame(equity_curve)
    trades_df = pd.DataFrame(trades) if trades else pd.DataFrame()
    
    # Ensure timestamp is datetime
    equity_df["timestamp"] = pd.to_datetime(equity_df["timestamp"])
    if not trades_df.empty and "timestamp" in trades_df.columns:
        trades_df["timestamp"] = pd.to_datetime(trades_df["timestamp"])
    
    # Create figure
    fig = go.Figure()
    
    # Add equity curve
    fig.add_trace(go.Scatter(
        x=equity_df["timestamp"],
        y=equity_df["equity"],
        mode="lines",
        name="Equity",
        line=dict(color="blue", width=2)
    ))
    
    # Add trade markers
    if not trades_df.empty and "action" in trades_df.columns and "price" in trades_df.columns:
        # Long entries
        long_entries = trades_df[trades_df["action"] == "open_long"]
        if not long_entries.empty:
            fig.add_trace(go.Scatter(
                x=long_entries["timestamp"],
                y=long_entries["price"],
                mode="markers",
                name="Long Entry",
                marker=dict(color="green", size=10, symbol="triangle-up")
            ))
        
        # Long exits
        long_exits = trades_df[trades_df["action"] == "close_long"]
        if not long_exits.empty:
            fig.add_trace(go.Scatter(
                x=long_exits["timestamp"],
                y=long_exits["price"],
                mode="markers",
                name="Long Exit",
                marker=dict(color="red", size=10, symbol="triangle-down")
            ))
        
        # Short entries
        short_entries = trades_df[trades_df["action"] == "open_short"]
        if not short_entries.empty:
            fig.add_trace(go.Scatter(
                x=short_entries["timestamp"],
                y=short_entries["price"],
                mode="markers",
                name="Short Entry",
                marker=dict(color="red", size=10, symbol="triangle-down")
            ))
        
        # Short exits
        short_exits = trades_df[trades_df["action"] == "close_short"]
        if not short_exits.empty:
            fig.add_trace(go.Scatter(
                x=short_exits["timestamp"],
                y=short_exits["price"],
                mode="markers",
                name="Short Exit",
                marker=dict(color="green", size=10, symbol="triangle-up")
            ))
    
    # Update layout
    fig.update_layout(
        title="Equity Curve with Trades",
        xaxis_title="Date",
        yaxis_title="Equity ($)",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
        template="plotly_white"
    )
    
    # Save to file if output path is provided
    if output_path:
        fig.write_html(output_path)
        logger.info(f"Equity chart saved to {output_path}")
    
    return fig

def create_drawdown_chart(
    equity_curve: List[Dict[str, Any]],
    output_path: Optional[str] = None
) -> go.Figure:
    """
    Create a drawdown chart.
    
    Args:
        equity_curve: List of equity points
        output_path: Path to save the chart (optional)
        
    Returns:
        Plotly figure
    """
    # Convert to DataFrame
    equity_df = pd.DataFrame(equity_curve)
    
    # Ensure timestamp is datetime
    equity_df["timestamp"] = pd.to_datetime(equity_df["timestamp"])
    
    # Create figure
    fig = go.Figure()
    
    # Add drawdown curve
    fig.add_trace(go.Scatter(
        x=equity_df["timestamp"],
        y=-equity_df["drawdown_pct"],  # Negative to show drawdowns going down
        mode="lines",
        name="Drawdown",
        fill="tozeroy",
        line=dict(color="red", width=2)
    ))
    
    # Update layout
    fig.update_layout(
        title="Drawdown Chart",
        xaxis_title="Date",
        yaxis_title="Drawdown (%)",
        yaxis=dict(
            tickformat=".2f",
            ticksuffix="%"
        ),
        template="plotly_white"
    )
    
    # Save to file if output path is provided
    if output_path:
        fig.write_html(output_path)
        logger.info(f"Drawdown chart saved to {output_path}")
    
    return fig

def create_monthly_returns_heatmap(
    equity_curve: List[Dict[str, Any]],
    output_path: Optional[str] = None
) -> go.Figure:
    """
    Create a monthly returns heatmap.
    
    Args:
        equity_curve: List of equity points
        output_path: Path to save the chart (optional)
        
    Returns:
        Plotly figure
    """
    # Convert to DataFrame
    equity_df = pd.DataFrame(equity_curve)
    
    # Ensure timestamp is datetime
    equity_df["timestamp"] = pd.to_datetime(equity_df["timestamp"])
    
    # Set timestamp as index
    equity_df.set_index("timestamp", inplace=True)
    
    # Calculate monthly returns
    monthly_returns = equity_df["equity"].resample("M").last().pct_change().dropna()
    
    # Create a DataFrame with years as rows and months as columns
    returns_matrix = pd.DataFrame()
    
    for date, ret in monthly_returns.items():
        year = date.year
        month = date.month
        
        if year not in returns_matrix.index:
            returns_matrix.loc[year] = [np.nan] * 12
            
        returns_matrix.loc[year, month-1] = ret
    
    # Set column names to month names
    returns_matrix.columns = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=returns_matrix.values * 100,  # Convert to percentage
        x=returns_matrix.columns,
        y=returns_matrix.index,
        colorscale="RdYlGn",  # Red for negative, green for positive
        zmid=0,  # Center the color scale at zero
        text=[[f"{val:.2f}%" if not np.isnan(val) else "" for val in row] for row in returns_matrix.values * 100],
        texttemplate="%{text}",
        textfont={"size": 10},
        colorbar=dict(
            title="Return (%)",
            titleside="right",
            ticksuffix="%"
        )
    ))
    
    # Update layout
    fig.update_layout(
        title="Monthly Returns Heatmap",
        xaxis_title="Month",
        yaxis_title="Year",
        yaxis=dict(
            autorange="reversed"  # To show most recent year at the top
        ),
        template="plotly_white"
    )
    
    # Save to file if output path is provided
    if output_path:
        fig.write_html(output_path)
        logger.info(f"Monthly returns heatmap saved to {output_path}")
    
    return fig

def create_performance_summary(
    metrics: Dict[str, Any],
    output_path: Optional[str] = None
) -> go.Figure:
    """
    Create a performance summary chart.
    
    Args:
        metrics: Dictionary of performance metrics
        output_path: Path to save the chart (optional)
        
    Returns:
        Plotly figure
    """
    # Create figure with subplots
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=(
            "Returns", 
            "Risk Metrics", 
            "Trade Statistics", 
            "Risk-Adjusted Returns"
        ),
        specs=[
            [{"type": "domain"}, {"type": "domain"}],
            [{"type": "domain"}, {"type": "domain"}]
        ]
    )
    
    # Returns gauge
    fig.add_trace(go.Indicator(
        mode="gauge+number+delta",
        value=metrics.get("total_return_pct", 0),
        title={"text": "Total Return"},
        delta={"reference": 0},
        gauge={
            "axis": {"range": [None, max(50, metrics.get("total_return_pct", 0) * 1.5)]},
            "bar": {"color": "green" if metrics.get("total_return_pct", 0) >= 0 else "red"},
            "steps": [
                {"range": [0, 10], "color": "lightgray"},
                {"range": [10, 20], "color": "gray"}
            ],
            "threshold": {
                "line": {"color": "black", "width": 4},
                "thickness": 0.75,
                "value": metrics.get("total_return_pct", 0)
            }
        },
        number={"suffix": "%"}
    ), row=1, col=1)
    
    # Risk metrics gauge
    fig.add_trace(go.Indicator(
        mode="gauge+number",
        value=metrics.get("max_drawdown_pct", 0),
        title={"text": "Max Drawdown"},
        gauge={
            "axis": {"range": [0, max(30, metrics.get("max_drawdown_pct", 0) * 1.5)]},
            "bar": {"color": "red"},
            "steps": [
                {"range": [0, 10], "color": "lightgray"},
                {"range": [10, 20], "color": "gray"}
            ],
            "threshold": {
                "line": {"color": "black", "width": 4},
                "thickness": 0.75,
                "value": metrics.get("max_drawdown_pct", 0)
            }
        },
        number={"suffix": "%"}
    ), row=1, col=2)
    
    # Trade statistics gauge
    fig.add_trace(go.Indicator(
        mode="gauge+number",
        value=metrics.get("win_rate", 0) * 100,
        title={"text": "Win Rate"},
        gauge={
            "axis": {"range": [0, 100]},
            "bar": {"color": "blue"},
            "steps": [
                {"range": [0, 40], "color": "lightgray"},
                {"range": [40, 60], "color": "gray"},
                {"range": [60, 100], "color": "lightblue"}
            ],
            "threshold": {
                "line": {"color": "black", "width": 4},
                "thickness": 0.75,
                "value": metrics.get("win_rate", 0) * 100
            }
        },
        number={"suffix": "%"}
    ), row=2, col=1)
    
    # Risk-adjusted returns gauge
    fig.add_trace(go.Indicator(
        mode="gauge+number",
        value=metrics.get("sharpe_ratio", 0),
        title={"text": "Sharpe Ratio"},
        gauge={
            "axis": {"range": [0, max(3, metrics.get("sharpe_ratio", 0) * 1.5)]},
            "bar": {"color": "purple"},
            "steps": [
                {"range": [0, 1], "color": "lightgray"},
                {"range": [1, 2], "color": "gray"},
                {"range": [2, 3], "color": "lightpurple"}
            ],
            "threshold": {
                "line": {"color": "black", "width": 4},
                "thickness": 0.75,
                "value": metrics.get("sharpe_ratio", 0)
            }
        }
    ), row=2, col=2)
    
    # Update layout
    fig.update_layout(
        title="Performance Summary",
        height=800,
        template="plotly_white"
    )
    
    # Save to file if output path is provided
    if output_path:
        fig.write_html(output_path)
        logger.info(f"Performance summary saved to {output_path}")
    
    return fig

def create_trade_analysis_chart(
    trades: List[Dict[str, Any]],
    output_path: Optional[str] = None
) -> go.Figure:
    """
    Create a trade analysis chart.
    
    Args:
        trades: List of trades
        output_path: Path to save the chart (optional)
        
    Returns:
        Plotly figure
    """
    # Convert to DataFrame
    trades_df = pd.DataFrame(trades) if trades else pd.DataFrame()
    
    if trades_df.empty or "profit" not in trades_df.columns:
        logger.warning("No trade data available for analysis")
        return None
    
    # Create figure with subplots
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=(
            "Profit Distribution", 
            "Cumulative Profit", 
            "Profit by Trade", 
            "Win/Loss Streak"
        ),
        specs=[
            [{"type": "histogram"}, {"type": "scatter"}],
            [{"type": "bar"}, {"type": "scatter"}]
        ]
    )
    
    # Profit distribution histogram
    fig.add_trace(go.Histogram(
        x=trades_df["profit"],
        name="Profit Distribution",
        marker_color="blue",
        opacity=0.7,
        nbinsx=20
    ), row=1, col=1)
    
    # Cumulative profit
    trades_df["cumulative_profit"] = trades_df["profit"].cumsum()
    fig.add_trace(go.Scatter(
        x=list(range(1, len(trades_df) + 1)),
        y=trades_df["cumulative_profit"],
        mode="lines",
        name="Cumulative Profit",
        line=dict(color="green", width=2)
    ), row=1, col=2)
    
    # Profit by trade
    fig.add_trace(go.Bar(
        x=list(range(1, len(trades_df) + 1)),
        y=trades_df["profit"],
        name="Profit by Trade",
        marker_color=["green" if p > 0 else "red" for p in trades_df["profit"]]
    ), row=2, col=1)
    
    # Win/loss streak
    trades_df["win"] = trades_df["profit"] > 0
    streak_data = []
    current_streak = 0
    current_streak_type = None
    
    for win in trades_df["win"]:
        if current_streak_type is None:
            current_streak_type = win
            current_streak = 1
        elif current_streak_type == win:
            current_streak += 1
        else:
            streak_data.append((current_streak_type, current_streak))
            current_streak_type = win
            current_streak = 1
    
    # Add the last streak
    if current_streak_type is not None:
        streak_data.append((current_streak_type, current_streak))
    
    # Convert streak data to DataFrame
    streak_df = pd.DataFrame(streak_data, columns=["win", "streak"])
    
    # Plot win streaks as positive, loss streaks as negative
    streak_df["plot_streak"] = streak_df.apply(
        lambda row: row["streak"] if row["win"] else -row["streak"], 
        axis=1
    )
    
    fig.add_trace(go.Bar(
        x=list(range(1, len(streak_df) + 1)),
        y=streak_df["plot_streak"],
        name="Win/Loss Streak",
        marker_color=["green" if s > 0 else "red" for s in streak_df["plot_streak"]]
    ), row=2, col=2)
    
    # Update layout
    fig.update_layout(
        title="Trade Analysis",
        height=800,
        template="plotly_white"
    )
    
    # Update axes
    fig.update_xaxes(title_text="Profit ($)", row=1, col=1)
    fig.update_yaxes(title_text="Frequency", row=1, col=1)
    
    fig.update_xaxes(title_text="Trade Number", row=1, col=2)
    fig.update_yaxes(title_text="Cumulative Profit ($)", row=1, col=2)
    
    fig.update_xaxes(title_text="Trade Number", row=2, col=1)
    fig.update_yaxes(title_text="Profit ($)", row=2, col=1)
    
    fig.update_xaxes(title_text="Streak Number", row=2, col=2)
    fig.update_yaxes(title_text="Streak Length (+ win, - loss)", row=2, col=2)
    
    # Save to file if output path is provided
    if output_path:
        fig.write_html(output_path)
        logger.info(f"Trade analysis chart saved to {output_path}")
    
    return fig
