import asyncio
import logging
import time
import threading
from typing import Dict, List, Optional, Union, Any, Tuple, Callable
from enum import Enum
import traceback
from prometheus_client import Counter, Gauge

from ..connectors.connector_factory import ConnectorFactory

# Set up logging
logger = logging.getLogger(__name__)

# Prometheus metrics
FAILOVER_COUNTER = Counter('exchange_failover_total', 'Number of exchange failovers', ['from_exchange', 'to_exchange'])
EXCHANGE_HEALTH_GAUGE = Gauge('exchange_health', 'Exchange health status (1=healthy, 0=unhealthy)', ['exchange'])
ORDER_COUNTER = Counter('orders_total', 'Number of orders placed', ['exchange', 'status', 'type'])


class ExchangeStatus(Enum):
    """Enum for exchange status"""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class ExchangeInfo:
    """Class to store exchange information and health status"""
    def __init__(self, name: str, connector: Any, priority: int):
        self.name = name
        self.connector = connector
        self.priority = priority
        self.status = ExchangeStatus.UNKNOWN
        self.last_check_time = 0
        self.consecutive_failures = 0
        self.max_consecutive_failures = 3  # Number of consecutive failures before marking as unhealthy
        self.health_check_interval = 30  # Seconds between health checks
        self.recovery_check_interval = 60  # Seconds between recovery checks for unhealthy exchanges

    def is_healthy(self) -> bool:
        """Check if the exchange is healthy"""
        return self.status == ExchangeStatus.HEALTHY

    def mark_healthy(self):
        """Mark the exchange as healthy"""
        if self.status != ExchangeStatus.HEALTHY:
            logger.info(f"Exchange {self.name} is now HEALTHY")
            self.status = ExchangeStatus.HEALTHY
            self.consecutive_failures = 0
            EXCHANGE_HEALTH_GAUGE.labels(exchange=self.name).set(1)

    def mark_unhealthy(self, reason: str = ""):
        """Mark the exchange as unhealthy"""
        if self.status != ExchangeStatus.UNHEALTHY:
            logger.warning(f"Exchange {self.name} is now UNHEALTHY. Reason: {reason}")
            self.status = ExchangeStatus.UNHEALTHY
            EXCHANGE_HEALTH_GAUGE.labels(exchange=self.name).set(0)

    def record_failure(self, reason: str = ""):
        """Record a failure and mark as unhealthy if threshold is reached"""
        self.consecutive_failures += 1
        logger.warning(f"Exchange {self.name} failure #{self.consecutive_failures}: {reason}")
        
        if self.consecutive_failures >= self.max_consecutive_failures:
            self.mark_unhealthy(reason)
        
    def record_success(self):
        """Record a successful operation"""
        if self.consecutive_failures > 0:
            self.consecutive_failures = 0
            logger.info(f"Exchange {self.name} operation successful, resetting failure counter")
        
        if self.status == ExchangeStatus.UNHEALTHY:
            self.mark_healthy()


class OrderRouter:
    """
    Order Router for handling failover between exchange connectors
    """
    _instance = None  # Singleton instance
    
    @classmethod
    def get_instance(cls):
        """Get the singleton instance of the OrderRouter"""
        if cls._instance is None:
            raise RuntimeError("OrderRouter has not been initialized. Call initialize() first.")
        return cls._instance
    
    @classmethod
    def initialize(cls, exchanges_config: List[Dict], health_check_interval: int = 30):
        """
        Initialize the OrderRouter with exchange configurations
        
        Args:
            exchanges_config: List of exchange configurations with name, api_key, api_secret, etc.
            health_check_interval: Interval in seconds for health checks
        """
        if cls._instance is None:
            cls._instance = OrderRouter(exchanges_config, health_check_interval)
        return cls._instance
    
    def __init__(self, exchanges_config: List[Dict], health_check_interval: int = 30):
        """
        Initialize the OrderRouter
        
        Args:
            exchanges_config: List of exchange configurations with name, api_key, api_secret, etc.
            health_check_interval: Interval in seconds for health checks
        """
        self.exchanges: List[ExchangeInfo] = []
        self.active_exchange: Optional[ExchangeInfo] = None
        self.health_check_interval = health_check_interval
        self.health_check_thread = None
        self.running = False
        self.lock = threading.RLock()  # Reentrant lock for thread safety
        
        # Initialize exchanges
        for i, config in enumerate(exchanges_config):
            name = config.get('name')
            api_key = config.get('api_key')
            api_secret = config.get('api_secret')
            passphrase = config.get('passphrase')  # For OKX
            testnet = config.get('testnet', False)
            priority = config.get('priority', i)  # Default priority based on order in list
            
            try:
                # Create connector using factory
                connector = ConnectorFactory.create_connector(
                    exchange=name,
                    api_key=api_key,
                    api_secret=api_secret,
                    passphrase=passphrase,
                    testnet=testnet
                )
                
                # Add to exchanges list
                exchange_info = ExchangeInfo(name, connector, priority)
                exchange_info.health_check_interval = health_check_interval
                self.exchanges.append(exchange_info)
                
                # Initialize Prometheus gauge
                EXCHANGE_HEALTH_GAUGE.labels(exchange=name).set(0)
                
                logger.info(f"Initialized exchange connector for {name} with priority {priority}")
            except Exception as e:
                logger.error(f"Failed to initialize exchange connector for {name}: {str(e)}")
        
        # Sort exchanges by priority
        self.exchanges.sort(key=lambda x: x.priority)
        
        if not self.exchanges:
            raise ValueError("No valid exchange connectors configured")
        
        # Start health check thread
        self.start_health_check()
    
    def start_health_check(self):
        """Start the health check thread"""
        if self.health_check_thread is None or not self.health_check_thread.is_alive():
            self.running = True
            self.health_check_thread = threading.Thread(target=self._health_check_loop, daemon=True)
            self.health_check_thread.start()
            logger.info("Health check thread started")
    
    def stop_health_check(self):
        """Stop the health check thread"""
        self.running = False
        if self.health_check_thread and self.health_check_thread.is_alive():
            self.health_check_thread.join(timeout=5)
            logger.info("Health check thread stopped")
    
    def _health_check_loop(self):
        """Health check loop to run in a separate thread"""
        while self.running:
            try:
                self._perform_health_checks()
                time.sleep(1)  # Sleep briefly to prevent CPU hogging
            except Exception as e:
                logger.error(f"Error in health check loop: {str(e)}")
                time.sleep(5)  # Sleep longer on error
    
    def _perform_health_checks(self):
        """Perform health checks on all exchanges"""
        current_time = time.time()
        
        for exchange in self.exchanges:
            # Skip if it's not time for a health check yet
            if exchange.status == ExchangeStatus.HEALTHY:
                if current_time - exchange.last_check_time < exchange.health_check_interval:
                    continue
            elif exchange.status == ExchangeStatus.UNHEALTHY:
                if current_time - exchange.last_check_time < exchange.recovery_check_interval:
                    continue
            
            exchange.last_check_time = current_time
            
            try:
                # Perform health check
                self._check_exchange_health(exchange)
            except Exception as e:
                logger.error(f"Error checking health for {exchange.name}: {str(e)}")
                exchange.record_failure(str(e))
        
        # Update active exchange if needed
        self._update_active_exchange()
    
    def _check_exchange_health(self, exchange: ExchangeInfo):
        """
        Check the health of an exchange
        
        Args:
            exchange: ExchangeInfo object to check
        """
        try:
            # Simple health check - get account info
            exchange.connector.get_account_info()
            
            # If we get here, the exchange is healthy
            exchange.record_success()
            logger.debug(f"Health check passed for {exchange.name}")
            
        except Exception as e:
            logger.warning(f"Health check failed for {exchange.name}: {str(e)}")
            exchange.record_failure(str(e))
    
    def _update_active_exchange(self):
        """Update the active exchange based on health and priority"""
        with self.lock:
            # Find the highest priority healthy exchange
            healthy_exchanges = [ex for ex in self.exchanges if ex.is_healthy()]
            
            if not healthy_exchanges:
                if self.active_exchange:
                    logger.critical("No healthy exchanges available! Using last active exchange as fallback.")
                    return
                else:
                    logger.critical("No healthy exchanges available and no active exchange set!")
                    # Use the highest priority exchange as a fallback
                    self.active_exchange = self.exchanges[0]
                    return
            
            # Sort by priority and take the first (highest priority)
            new_active = min(healthy_exchanges, key=lambda x: x.priority)
            
            # If active exchange changed, log the failover
            if self.active_exchange != new_active:
                old_exchange = self.active_exchange.name if self.active_exchange else "none"
                logger.info(f"Failover from {old_exchange} to {new_active.name}")
                
                if self.active_exchange:
                    FAILOVER_COUNTER.labels(
                        from_exchange=self.active_exchange.name,
                        to_exchange=new_active.name
                    ).inc()
                
                self.active_exchange = new_active
    
    def get_active_exchange(self) -> ExchangeInfo:
        """
        Get the currently active exchange
        
        Returns:
            Active ExchangeInfo object
        """
        with self.lock:
            if not self.active_exchange:
                self._update_active_exchange()
            return self.active_exchange
    
    def _execute_with_failover(self, operation: str, func: Callable, *args, **kwargs):
        """
        Execute a function with failover logic
        
        Args:
            operation: Name of the operation for logging
            func: Function to execute
            *args: Arguments to pass to the function
            **kwargs: Keyword arguments to pass to the function
            
        Returns:
            Result of the function
        """
        with self.lock:
            # Get the active exchange
            active_exchange = self.get_active_exchange()
            
            # Try with the active exchange first
            try:
                logger.debug(f"Executing {operation} on {active_exchange.name}")
                result = func(active_exchange.connector, *args, **kwargs)
                active_exchange.record_success()
                return result
            except Exception as e:
                logger.error(f"Error executing {operation} on {active_exchange.name}: {str(e)}")
                active_exchange.record_failure(str(e))
                
                # Try failover to other exchanges
                for exchange in self.exchanges:
                    if exchange == active_exchange or not exchange.is_healthy():
                        continue
                    
                    try:
                        logger.info(f"Failover: Executing {operation} on {exchange.name}")
                        result = func(exchange.connector, *args, **kwargs)
                        exchange.record_success()
                        
                        # Update active exchange
                        FAILOVER_COUNTER.labels(
                            from_exchange=active_exchange.name,
                            to_exchange=exchange.name
                        ).inc()
                        self.active_exchange = exchange
                        
                        return result
                    except Exception as e:
                        logger.error(f"Failover error executing {operation} on {exchange.name}: {str(e)}")
                        exchange.record_failure(str(e))
                
                # If we get here, all exchanges failed
                logger.critical(f"All exchanges failed for operation {operation}")
                raise Exception(f"All exchanges failed for operation {operation}")
    
    # Exchange operation methods with failover
    
    def get_account_info(self) -> Dict:
        """
        Get account information from the active exchange
        
        Returns:
            Account information
        """
        return self._execute_with_failover(
            "get_account_info",
            lambda connector: connector.get_account_info()
        )
    
    def get_positions(self, symbol: Optional[str] = None) -> List[Dict]:
        """
        Get positions from the active exchange
        
        Args:
            symbol: Symbol to get positions for
            
        Returns:
            List of positions
        """
        return self._execute_with_failover(
            "get_positions",
            lambda connector, sym: connector.get_positions(sym),
            symbol
        )
    
    def fetch_ohlcv(self, symbol: str, timeframe: str = '1h', limit: int = 100) -> List[Dict]:
        """
        Fetch OHLCV data from the active exchange
        
        Args:
            symbol: Symbol to fetch data for
            timeframe: Timeframe (1m, 5m, 15m, 30m, 1h, 4h, 1d)
            limit: Number of candles to fetch
            
        Returns:
            List of OHLCV data
        """
        return self._execute_with_failover(
            "fetch_ohlcv",
            lambda connector, sym, tf, lim: connector.fetch_ohlcv(sym, tf, lim),
            symbol, timeframe, limit
        )
    
    def fetch_order_book(self, symbol: str, limit: int = 50) -> Dict:
        """
        Fetch order book from the active exchange
        
        Args:
            symbol: Symbol to fetch order book for
            limit: Depth of the order book
            
        Returns:
            Order book data
        """
        return self._execute_with_failover(
            "fetch_order_book",
            lambda connector, sym, lim: connector.fetch_order_book(sym, lim),
            symbol, limit
        )
    
    def create_order(self, symbol: str, side: str, order_type: str, quantity: float,
                    price: Optional[float] = None, time_in_force: str = 'GTC',
                    reduce_only: bool = False, close_on_trigger: bool = False) -> Dict:
        """
        Create an order on the active exchange
        
        Args:
            symbol: Symbol to create order for
            side: Order side (Buy, Sell)
            order_type: Order type (Market, Limit)
            quantity: Order quantity
            price: Order price (required for Limit orders)
            time_in_force: Time in force (GTC, IOC, FOK)
            reduce_only: Whether the order is reduce-only
            close_on_trigger: Whether to close position on trigger
            
        Returns:
            Order information
        """
        try:
            result = self._execute_with_failover(
                "create_order",
                lambda connector, sym, s, ot, qty, p, tif, ro, cot: connector.create_order(
                    symbol=sym, side=s, order_type=ot, quantity=qty,
                    price=p, time_in_force=tif, reduce_only=ro, close_on_trigger=cot
                ),
                symbol, side, order_type, quantity, price, time_in_force, reduce_only, close_on_trigger
            )
            
            # Increment order counter
            ORDER_COUNTER.labels(
                exchange=self.active_exchange.name,
                status="success",
                type=order_type
            ).inc()
            
            return result
        except Exception as e:
            # Increment order counter for failures
            ORDER_COUNTER.labels(
                exchange=self.active_exchange.name if self.active_exchange else "unknown",
                status="failure",
                type=order_type
            ).inc()
            
            raise
    
    def modify_order(self, symbol: str, order_id: str, price: Optional[float] = None,
                    quantity: Optional[float] = None) -> Dict:
        """
        Modify an order on the active exchange
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to modify
            price: New price
            quantity: New quantity
            
        Returns:
            Modified order information
        """
        return self._execute_with_failover(
            "modify_order",
            lambda connector, sym, oid, p, qty: connector.modify_order(
                symbol=sym, order_id=oid, price=p, quantity=qty
            ),
            symbol, order_id, price, quantity
        )
    
    def cancel_order(self, symbol: str, order_id: str) -> Dict:
        """
        Cancel an order on the active exchange
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to cancel
            
        Returns:
            Cancelled order information
        """
        return self._execute_with_failover(
            "cancel_order",
            lambda connector, sym, oid: connector.cancel_order(symbol=sym, order_id=oid),
            symbol, order_id
        )
    
    def close_position(self, symbol: str) -> Dict:
        """
        Close a position on the active exchange
        
        Args:
            symbol: Symbol of the position to close
            
        Returns:
            Closed position information
        """
        return self._execute_with_failover(
            "close_position",
            lambda connector, sym: connector.close_position(symbol=sym),
            symbol
        )
    
    def set_leverage(self, symbol: str, leverage: int) -> Dict:
        """
        Set leverage for a symbol on the active exchange
        
        Args:
            symbol: Symbol to set leverage for
            leverage: Leverage value
            
        Returns:
            Response data
        """
        return self._execute_with_failover(
            "set_leverage",
            lambda connector, sym, lev: connector.set_leverage(symbol=sym, leverage=lev),
            symbol, leverage
        )
    
    def set_stop_loss(self, symbol: str, stop_loss: float, position_side: str = None) -> Dict:
        """
        Set stop loss for a position on the active exchange
        
        Args:
            symbol: Symbol to set stop loss for
            stop_loss: Stop loss price
            position_side: Position side (Buy, Sell)
            
        Returns:
            Response data
        """
        return self._execute_with_failover(
            "set_stop_loss",
            lambda connector, sym, sl, ps: connector.set_stop_loss(
                symbol=sym, stop_loss=sl, position_side=ps
            ),
            symbol, stop_loss, position_side
        )
    
    def set_trailing_stop(self, symbol: str, trailing_stop: float, position_side: str = None) -> Dict:
        """
        Set trailing stop for a position on the active exchange
        
        Args:
            symbol: Symbol to set trailing stop for
            trailing_stop: Trailing stop value
            position_side: Position side (Buy, Sell)
            
        Returns:
            Response data
        """
        return self._execute_with_failover(
            "set_trailing_stop",
            lambda connector, sym, ts, ps: connector.set_trailing_stop(
                symbol=sym, trailing_stop=ts, position_side=ps
            ),
            symbol, trailing_stop, position_side
        )
    
    def get_exchange_status(self) -> Dict[str, str]:
        """
        Get the status of all exchanges
        
        Returns:
            Dictionary of exchange names and their status
        """
        return {
            exchange.name: exchange.status.value
            for exchange in self.exchanges
        }


# Convenience function to get the OrderRouter instance
def get_order_router() -> OrderRouter:
    """
    Get the OrderRouter instance
    
    Returns:
        OrderRouter instance
    """
    return OrderRouter.get_instance()
