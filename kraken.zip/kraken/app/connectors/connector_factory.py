from typing import Dict, Type, Optional
from .bybit import BybitV5Connector
from .okx import OKXConnector
from .binance import BinanceConnector

class ConnectorFactory:
    """
    Factory class for creating exchange connectors
    """
    
    # Map of exchange names to connector classes
    _connectors: Dict[str, Type] = {
        "bybit": BybitV5Connector,
        "okx": OKXConnector,
        "binance": BinanceConnector
    }
    
    @classmethod
    def create_connector(cls, exchange: str, api_key: Optional[str] = None, 
                        api_secret: Optional[str] = None, passphrase: Optional[str] = None,
                        testnet: bool = False):
        """
        Create a connector for the specified exchange
        
        Args:
            exchange: Exchange name (bybit, okx, binance)
            api_key: API key for authentication
            api_secret: API secret for authentication
            passphrase: API passphrase for authentication (required for OKX)
            testnet: Whether to use testnet
            
        Returns:
            Exchange connector instance
        """
        if exchange not in cls._connectors:
            raise ValueError(f"Unsupported exchange: {exchange}")
        
        connector_class = cls._connectors[exchange]
        
        # Handle OKX which requires a passphrase
        if exchange == "okx":
            return connector_class(api_key, api_secret, passphrase, testnet)
        else:
            return connector_class(api_key, api_secret, testnet)
