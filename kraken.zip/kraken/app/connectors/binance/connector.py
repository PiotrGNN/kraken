import os
import time
import logging
import ccxt
from typing import Dict, List, Optional, Union, Any
from functools import wraps

logger = logging.getLogger(__name__)

def rate_limit(func):
    """
    Decorator to handle rate limiting for Binance API calls
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        self._handle_rate_limit()
        return func(self, *args, **kwargs)
    return wrapper

class BinanceConnector:
    """
    Connector for Binance API using CCXT library
    """
    def __init__(self, api_key: str = None, api_secret: str = None, testnet: bool = False):
        """
        Initialize the Binance connector
        
        Args:
            api_key: API key for authentication
            api_secret: API secret for authentication
            testnet: Whether to use testnet
        """
        self.api_key = api_key or os.environ.get('BINANCE_API_KEY')
        self.api_secret = api_secret or os.environ.get('BINANCE_API_SECRET')
        
        if not self.api_key or not self.api_secret:
            raise ValueError("API key and secret are required for Binance connector")
        
        # Initialize CCXT Binance client
        options = {
            'adjustForTimeDifference': True,
            'recvWindow': 5000,
        }
        
        if testnet:
            options['defaultType'] = 'future'
            self.exchange = ccxt.binance({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'options': options,
                'urls': {
                    'api': {
                        'public': 'https://testnet.binancefuture.com/fapi/v1',
                        'private': 'https://testnet.binancefuture.com/fapi/v1',
                    },
                }
            })
        else:
            options['defaultType'] = 'future'
            self.exchange = ccxt.binance({
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'options': options
            })
        
        # Rate limiting
        self.request_count = 0
        self.request_limit = 20  # Requests per second
        self.last_request_time = time.time()
    
    def _handle_rate_limit(self):
        """
        Handle rate limiting
        """
        current_time = time.time()
        elapsed = current_time - self.last_request_time
        
        if elapsed >= 1:
            # Reset counter after 1 second
            self.request_count = 0
            self.last_request_time = current_time
        elif self.request_count >= self.request_limit:
            # Sleep if we've hit the limit
            sleep_time = 1 - elapsed
            logger.info(f"Rate limit reached, sleeping for {sleep_time:.2f} seconds")
            time.sleep(sleep_time)
            self.request_count = 0
            self.last_request_time = time.time()
            
        self.request_count += 1
    
    @rate_limit
    def get_account_info(self) -> Dict:
        """
        Get account information
        
        Returns:
            Account information
        """
        try:
            # Get account balance
            balance = self.exchange.fetch_balance()
            
            # Format the response to match other connectors
            formatted_balance = {
                'totalEquity': balance['total'],
                'availableBalance': balance['free'],
                'positions': balance['info'].get('positions', [])
            }
            
            return formatted_balance
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error getting account info: {str(e)}")
            raise
    
    @rate_limit
    def get_positions(self, symbol: Optional[str] = None) -> List[Dict]:
        """
        Get positions
        
        Args:
            symbol: Symbol to get positions for
            
        Returns:
            List of positions
        """
        try:
            positions = self.exchange.fetch_positions(symbol)
            
            # Format positions to match other connectors
            formatted_positions = []
            for position in positions:
                if float(position['contracts']) > 0:
                    formatted_position = {
                        'symbol': position['symbol'],
                        'side': 'Buy' if position['side'] == 'long' else 'Sell',
                        'size': position['contracts'],
                        'entryPrice': position['entryPrice'],
                        'markPrice': position['markPrice'],
                        'unrealizedPnl': position['unrealizedPnl'],
                        'leverage': position['leverage']
                    }
                    formatted_positions.append(formatted_position)
            
            return formatted_positions
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error getting positions: {str(e)}")
            raise
    
    @rate_limit
    def fetch_ohlcv(self, symbol: str, timeframe: str = '1h', limit: int = 100) -> List[Dict]:
        """
        Fetch OHLCV data
        
        Args:
            symbol: Symbol to fetch data for
            timeframe: Timeframe (1m, 5m, 15m, 30m, 1h, 4h, 1d)
            limit: Number of candles to fetch
            
        Returns:
            List of OHLCV data
        """
        try:
            # Map timeframe to CCXT format if needed
            timeframe_map = {
                '1m': '1m',
                '5m': '5m',
                '15m': '15m',
                '30m': '30m',
                '1h': '1h',
                '4h': '4h',
                '1d': '1d',
                '1H': '1h',
                '4H': '4h',
                '1D': '1d'
            }
            
            tf = timeframe_map.get(timeframe, timeframe)
            
            # Fetch OHLCV data
            ohlcv = self.exchange.fetch_ohlcv(symbol, tf, limit=limit)
            
            # Format the response to match other connectors
            formatted_ohlcv = []
            for candle in ohlcv:
                formatted_candle = {
                    'timestamp': candle[0],
                    'open': candle[1],
                    'high': candle[2],
                    'low': candle[3],
                    'close': candle[4],
                    'volume': candle[5]
                }
                formatted_ohlcv.append(formatted_candle)
            
            return formatted_ohlcv
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error fetching OHLCV data: {str(e)}")
            raise
    
    @rate_limit
    def fetch_order_book(self, symbol: str, limit: int = 50) -> Dict:
        """
        Fetch order book
        
        Args:
            symbol: Symbol to fetch order book for
            limit: Depth of the order book
            
        Returns:
            Order book data
        """
        try:
            order_book = self.exchange.fetch_order_book(symbol, limit)
            
            # Format the response to match other connectors
            formatted_order_book = {
                'bids': order_book['bids'],
                'asks': order_book['asks'],
                'timestamp': order_book['timestamp'],
                'datetime': order_book['datetime']
            }
            
            return formatted_order_book
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error fetching order book: {str(e)}")
            raise
    
    @rate_limit
    def create_order(self, symbol: str, side: str, order_type: str, quantity: float,
                    price: Optional[float] = None, time_in_force: str = 'GTC',
                    reduce_only: bool = False, close_on_trigger: bool = False) -> Dict:
        """
        Create an order
        
        Args:
            symbol: Symbol to create order for
            side: Order side (Buy, Sell)
            order_type: Order type (Market, Limit)
            quantity: Order quantity
            price: Order price (required for Limit orders)
            time_in_force: Time in force (GTC, IOC, FOK)
            reduce_only: Whether the order is reduce-only
            close_on_trigger: Whether to close position on trigger (not used in Binance)
            
        Returns:
            Order information
        """
        try:
            # Map parameters to CCXT format
            ccxt_side = side.lower()
            ccxt_type = order_type.lower()
            
            # Prepare parameters
            params = {
                'timeInForce': time_in_force,
                'reduceOnly': reduce_only
            }
            
            # Create order
            if ccxt_type == 'limit':
                if price is None:
                    raise ValueError("Price is required for limit orders")
                
                order = self.exchange.create_order(
                    symbol=symbol,
                    type=ccxt_type,
                    side=ccxt_side,
                    amount=quantity,
                    price=price,
                    params=params
                )
            else:  # Market order
                order = self.exchange.create_order(
                    symbol=symbol,
                    type=ccxt_type,
                    side=ccxt_side,
                    amount=quantity,
                    params=params
                )
            
            # Format the response to match other connectors
            formatted_order = {
                'orderId': order['id'],
                'symbol': order['symbol'],
                'side': order['side'].capitalize(),
                'orderType': order['type'].capitalize(),
                'price': order['price'],
                'origQty': order['amount'],
                'executedQty': order['filled'],
                'status': order['status'],
                'timeInForce': order.get('timeInForce', time_in_force),
                'reduceOnly': reduce_only
            }
            
            return formatted_order
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error creating order: {str(e)}")
            raise
    
    @rate_limit
    def modify_order(self, symbol: str, order_id: str, price: Optional[float] = None,
                    quantity: Optional[float] = None) -> Dict:
        """
        Modify an order
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to modify
            price: New price
            quantity: New quantity
            
        Returns:
            Modified order information
        """
        try:
            # Cancel the existing order
            self.cancel_order(symbol, order_id)
            
            # Get the original order details
            orders = self.exchange.fetch_orders(symbol)
            original_order = None
            for order in orders:
                if order['id'] == order_id:
                    original_order = order
                    break
            
            if not original_order:
                raise ValueError(f"Order {order_id} not found")
            
            # Create a new order with the modified parameters
            new_price = price if price is not None else original_order['price']
            new_quantity = quantity if quantity is not None else original_order['amount']
            
            new_order = self.create_order(
                symbol=symbol,
                side=original_order['side'].capitalize(),
                order_type=original_order['type'].capitalize(),
                quantity=new_quantity,
                price=new_price,
                time_in_force=original_order.get('timeInForce', 'GTC'),
                reduce_only=original_order.get('reduceOnly', False)
            )
            
            return new_order
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error modifying order: {str(e)}")
            raise
    
    @rate_limit
    def cancel_order(self, symbol: str, order_id: str) -> Dict:
        """
        Cancel an order
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to cancel
            
        Returns:
            Cancelled order information
        """
        try:
            order = self.exchange.cancel_order(order_id, symbol)
            
            # Format the response to match other connectors
            formatted_order = {
                'orderId': order['id'],
                'symbol': order['symbol'],
                'status': order['status'],
                'message': 'Order cancelled successfully'
            }
            
            return formatted_order
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error cancelling order: {str(e)}")
            raise
    
    @rate_limit
    def close_position(self, symbol: str) -> Dict:
        """
        Close a position
        
        Args:
            symbol: Symbol of the position to close
            
        Returns:
            Closed position information
        """
        try:
            # Get current position
            positions = self.get_positions(symbol)
            if not positions:
                logger.info(f"No position to close for {symbol}")
                return {'success': True, 'message': f"No position to close for {symbol}"}
            
            # Find the position for the symbol
            position = None
            for pos in positions:
                if pos['symbol'] == symbol:
                    position = pos
                    break
            
            if not position:
                logger.info(f"No position to close for {symbol}")
                return {'success': True, 'message': f"No position to close for {symbol}"}
            
            # Get position size and side
            pos_size = float(position['size'])
            pos_side = position['side']
            
            if pos_size == 0:
                logger.info(f"No position to close for {symbol}")
                return {'success': True, 'message': f"No position to close for {symbol}"}
            
            # Create market order to close position
            close_side = 'Sell' if pos_side == 'Buy' else 'Buy'
            
            order = self.create_order(
                symbol=symbol,
                side=close_side,
                order_type='Market',
                quantity=pos_size,
                reduce_only=True
            )
            
            return {
                'success': True,
                'message': f"Position closed for {symbol}",
                'order': order
            }
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error closing position: {str(e)}")
            raise
    
    @rate_limit
    def set_leverage(self, symbol: str, leverage: int) -> Dict:
        """
        Set leverage for a symbol
        
        Args:
            symbol: Symbol to set leverage for
            leverage: Leverage value
            
        Returns:
            Response data
        """
        try:
            result = self.exchange.set_leverage(leverage, symbol)
            
            return {
                'success': True,
                'message': f"Leverage set to {leverage} for {symbol}",
                'data': result
            }
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error setting leverage: {str(e)}")
            raise
    
    @rate_limit
    def set_stop_loss(self, symbol: str, stop_loss: float, position_side: str = None) -> Dict:
        """
        Set stop loss for a position
        
        Args:
            symbol: Symbol to set stop loss for
            stop_loss: Stop loss price
            position_side: Position side (Buy, Sell)
            
        Returns:
            Response data
        """
        try:
            # Get current position
            positions = self.get_positions(symbol)
            if not positions:
                logger.info(f"No position to set stop loss for {symbol}")
                return {'success': False, 'message': f"No position to set stop loss for {symbol}"}
            
            # Find the position for the symbol
            position = None
            for pos in positions:
                if pos['symbol'] == symbol:
                    position = pos
                    break
            
            if not position:
                logger.info(f"No position to set stop loss for {symbol}")
                return {'success': False, 'message': f"No position to set stop loss for {symbol}"}
            
            # Get position size and side
            pos_size = float(position['size'])
            pos_side = position['side'] if not position_side else position_side
            
            if pos_size == 0:
                logger.info(f"No position to set stop loss for {symbol}")
                return {'success': False, 'message': f"No position to set stop loss for {symbol}"}
            
            # Create stop loss order
            sl_side = 'Sell' if pos_side == 'Buy' else 'Buy'
            
            params = {
                'stopPrice': stop_loss,
                'reduceOnly': True,
                'type': 'stop_market'
            }
            
            order = self.exchange.create_order(
                symbol=symbol,
                type='stop',
                side=sl_side.lower(),
                amount=pos_size,
                price=stop_loss,
                params=params
            )
            
            return {
                'success': True,
                'message': f"Stop loss set at {stop_loss} for {symbol}",
                'order': order
            }
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error setting stop loss: {str(e)}")
            raise
    
    @rate_limit
    def set_trailing_stop(self, symbol: str, callback_rate: float, position_side: str = None) -> Dict:
        """
        Set trailing stop for a position
        
        Args:
            symbol: Symbol to set trailing stop for
            callback_rate: Callback rate for trailing stop (e.g., 0.05 for 5%)
            position_side: Position side (Buy, Sell)
            
        Returns:
            Response data
        """
        try:
            # Get current position
            positions = self.get_positions(symbol)
            if not positions:
                logger.info(f"No position to set trailing stop for {symbol}")
                return {'success': False, 'message': f"No position to set trailing stop for {symbol}"}
            
            # Find the position for the symbol
            position = None
            for pos in positions:
                if pos['symbol'] == symbol:
                    position = pos
                    break
            
            if not position:
                logger.info(f"No position to set trailing stop for {symbol}")
                return {'success': False, 'message': f"No position to set trailing stop for {symbol}"}
            
            # Get position size and side
            pos_size = float(position['size'])
            pos_side = position['side'] if not position_side else position_side
            
            if pos_size == 0:
                logger.info(f"No position to set trailing stop for {symbol}")
                return {'success': False, 'message': f"No position to set trailing stop for {symbol}"}
            
            # Create trailing stop order
            ts_side = 'Sell' if pos_side == 'Buy' else 'Buy'
            
            # Convert callback rate to percentage
            callback_percent = callback_rate * 100
            
            params = {
                'callbackRate': callback_percent,
                'reduceOnly': True,
                'type': 'trailing_stop_market'
            }
            
            # For Binance, we need to use the current market price as activation price
            market_price = self.exchange.fetch_ticker(symbol)['last']
            
            order = self.exchange.create_order(
                symbol=symbol,
                type='trailing_stop',
                side=ts_side.lower(),
                amount=pos_size,
                price=market_price,  # This is ignored for trailing stops but required by CCXT
                params=params
            )
            
            return {
                'success': True,
                'message': f"Trailing stop set with callback rate {callback_percent}% for {symbol}",
                'order': order
            }
        except ccxt.NetworkError as e:
            logger.error(f"Network error: {str(e)}")
            raise
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error setting trailing stop: {str(e)}")
            raise
