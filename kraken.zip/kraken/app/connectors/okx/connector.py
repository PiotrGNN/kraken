import os
import time
import logging
import hmac
import hashlib
import base64
import json
from typing import Dict, List, Optional, Union, Any
import requests
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

class OKXConnector:
    """
    Connector for OKX API
    """
    def __init__(self, api_key: str = None, api_secret: str = None, passphrase: str = None, testnet: bool = False):
        """
        Initialize the OKX connector
        
        Args:
            api_key: API key for authentication
            api_secret: API secret for authentication
            passphrase: API passphrase for authentication
            testnet: Whether to use testnet
        """
        self.api_key = api_key or os.environ.get('OKX_API_KEY')
        self.api_secret = api_secret or os.environ.get('OKX_API_SECRET')
        self.passphrase = passphrase or os.environ.get('OKX_PASSPHRASE')
        
        if not self.api_key or not self.api_secret or not self.passphrase:
            raise ValueError("API key, secret, and passphrase are required for OKX connector")
        
        self.base_url = "https://www.okx.com" if not testnet else "https://www.okx.com"
        self.session = requests.Session()
        
        # Rate limiting
        self.request_count = 0
        self.request_limit = 20  # Requests per 2 seconds
        self.last_request_time = time.time()
    
    def _generate_signature(self, timestamp: str, method: str, request_path: str, body: str = '') -> str:
        """
        Generate signature for authentication
        
        Args:
            timestamp: ISO timestamp
            method: HTTP method
            request_path: API endpoint
            body: Request body
            
        Returns:
            Signature string
        """
        message = timestamp + method + request_path + (body if body else '')
        
        signature = base64.b64encode(
            hmac.new(
                self.api_secret.encode('utf-8'),
                message.encode('utf-8'),
                hashlib.sha256
            ).digest()
        ).decode('utf-8')
        
        return signature
    
    def _handle_rate_limit(self):
        """
        Handle rate limiting
        """
        current_time = time.time()
        elapsed = current_time - self.last_request_time
        
        if elapsed >= 2:
            # Reset counter after 2 seconds
            self.request_count = 0
            self.last_request_time = current_time
        elif self.request_count >= self.request_limit:
            # Sleep if we've hit the limit
            sleep_time = 2 - elapsed
            logger.info(f"Rate limit reached, sleeping for {sleep_time:.2f} seconds")
            time.sleep(sleep_time)
            self.request_count = 0
            self.last_request_time = time.time()
            
        self.request_count += 1
    
    def _request(self, method: str, endpoint: str, params: Dict = None, data: Dict = None, signed: bool = True) -> Dict:
        """
        Make a request to the OKX API
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            params: Query parameters
            data: Request body
            signed: Whether the request needs to be signed
            
        Returns:
            Response data
        """
        self._handle_rate_limit()
        
        url = f"{self.base_url}{endpoint}"
        
        # Prepare request
        headers = {
            'Content-Type': 'application/json'
        }
        
        if signed:
            timestamp = str(time.time())
            
            # Convert data to JSON string if it exists
            data_str = json.dumps(data) if data else ''
            
            # Generate signature
            signature = self._generate_signature(timestamp, method, endpoint, data_str)
            
            # Add authentication headers
            headers.update({
                'OK-ACCESS-KEY': self.api_key,
                'OK-ACCESS-SIGN': signature,
                'OK-ACCESS-TIMESTAMP': timestamp,
                'OK-ACCESS-PASSPHRASE': self.passphrase
            })
        
        try:
            if method == 'GET':
                response = self.session.get(url, params=params, headers=headers)
            elif method == 'POST':
                response = self.session.post(url, params=params, json=data, headers=headers)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            data = response.json()
            
            if data['code'] != '0':
                logger.error(f"API error: {data['msg']}")
                raise Exception(f"OKX API error: {data['msg']}")
            
            return data['data']
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error in request: {str(e)}")
            raise
    
    def get_account_info(self) -> Dict:
        """
        Get account information
        
        Returns:
            Account information
        """
        endpoint = "/api/v5/account/balance"
        return self._request('GET', endpoint)
    
    def get_positions(self, symbol: Optional[str] = None) -> List[Dict]:
        """
        Get positions
        
        Args:
            symbol: Symbol to get positions for
            
        Returns:
            List of positions
        """
        endpoint = "/api/v5/account/positions"
        params = {}
        if symbol:
            params['instId'] = symbol
        
        return self._request('GET', endpoint, params)
    
    def fetch_ohlcv(self, symbol: str, timeframe: str = '1H', limit: int = 100) -> List[Dict]:
        """
        Fetch OHLCV data
        
        Args:
            symbol: Symbol to fetch data for
            timeframe: Timeframe (1m, 5m, 15m, 30m, 1H, 4H, 1D)
            limit: Number of candles to fetch
            
        Returns:
            List of OHLCV data
        """
        endpoint = "/api/v5/market/candles"
        params = {
            'instId': symbol,
            'bar': timeframe,
            'limit': limit
        }
        
        return self._request('GET', endpoint, params, signed=False)
    
    def fetch_order_book(self, symbol: str, limit: int = 50) -> Dict:
        """
        Fetch order book
        
        Args:
            symbol: Symbol to fetch order book for
            limit: Depth of the order book
            
        Returns:
            Order book data
        """
        endpoint = "/api/v5/market/books"
        params = {
            'instId': symbol,
            'sz': limit
        }
        
        return self._request('GET', endpoint, params, signed=False)
    
    def create_order(self, symbol: str, side: str, order_type: str, quantity: float,
                    price: Optional[float] = None, reduce_only: bool = False) -> Dict:
        """
        Create an order
        
        Args:
            symbol: Symbol to create order for
            side: Order side (buy, sell)
            order_type: Order type (market, limit)
            quantity: Order quantity
            price: Order price (required for limit orders)
            reduce_only: Whether the order is reduce-only
            
        Returns:
            Order information
        """
        endpoint = "/api/v5/trade/order"
        data = {
            'instId': symbol,
            'tdMode': 'cross',
            'side': side.lower(),
            'ordType': order_type.lower(),
            'sz': str(quantity)
        }
        
        if order_type.lower() == 'limit' and price is not None:
            data['px'] = str(price)
        
        if reduce_only:
            data['reduceOnly'] = 'true'
        
        return self._request('POST', endpoint, data=data)
    
    def modify_order(self, symbol: str, order_id: str, price: Optional[float] = None,
                    quantity: Optional[float] = None) -> Dict:
        """
        Modify an order
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to modify
            price: New price
            quantity: New quantity
            
        Returns:
            Modified order information
        """
        endpoint = "/api/v5/trade/amend-order"
        data = {
            'instId': symbol,
            'ordId': order_id
        }
        
        if price is not None:
            data['newPx'] = str(price)
        
        if quantity is not None:
            data['newSz'] = str(quantity)
        
        return self._request('POST', endpoint, data=data)
    
    def cancel_order(self, symbol: str, order_id: str) -> Dict:
        """
        Cancel an order
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to cancel
            
        Returns:
            Cancelled order information
        """
        endpoint = "/api/v5/trade/cancel-order"
        data = {
            'instId': symbol,
            'ordId': order_id
        }
        
        return self._request('POST', endpoint, data=data)
    
    def close_position(self, symbol: str) -> Dict:
        """
        Close a position
        
        Args:
            symbol: Symbol of the position to close
            
        Returns:
            Closed position information
        """
        # Get current position
        positions = self.get_positions(symbol)
        if not positions:
            logger.info(f"No position to close for {symbol}")
            return {'success': True, 'message': f"No position to close for {symbol}"}
        
        # Find the position for the symbol
        position = None
        for pos in positions:
            if pos['instId'] == symbol:
                position = pos
                break
        
        if not position or float(position['pos']) == 0:
            logger.info(f"No position to close for {symbol}")
            return {'success': True, 'message': f"No position to close for {symbol}"}
        
        # Get position size and side
        pos_size = abs(float(position['pos']))
        pos_side = 'buy' if float(position['pos']) < 0 else 'sell'
        
        # Create market order to close position
        close_side = 'buy' if pos_side == 'sell' else 'sell'
        
        return self.create_order(
            symbol=symbol,
            side=close_side,
            order_type='market',
            quantity=pos_size,
            reduce_only=True
        )
    
    def set_leverage(self, symbol: str, leverage: int) -> Dict:
        """
        Set leverage for a symbol
        
        Args:
            symbol: Symbol to set leverage for
            leverage: Leverage value
            
        Returns:
            Response data
        """
        endpoint = "/api/v5/account/set-leverage"
        data = {
            'instId': symbol,
            'lever': str(leverage),
            'mgnMode': 'cross'
        }
        
        return self._request('POST', endpoint, data=data)
    
    def set_stop_loss(self, symbol: str, stop_loss: float, position_side: str = None) -> Dict:
        """
        Set stop loss for a position
        
        Args:
            symbol: Symbol to set stop loss for
            stop_loss: Stop loss price
            position_side: Position side (long, short)
            
        Returns:
            Response data
        """
        endpoint = "/api/v5/trade/order"
        
        # Determine the side for the stop loss order
        sl_side = 'sell' if position_side == 'long' else 'buy'
        
        # Get position size
        positions = self.get_positions(symbol)
        position = None
        for pos in positions:
            if pos['instId'] == symbol:
                position = pos
                break
        
        if not position or float(position['pos']) == 0:
            logger.info(f"No position to set stop loss for {symbol}")
            return {'success': False, 'message': f"No position to set stop loss for {symbol}"}
        
        pos_size = abs(float(position['pos']))
        
        # Create stop loss order
        data = {
            'instId': symbol,
            'tdMode': 'cross',
            'side': sl_side,
            'ordType': 'conditional',
            'sz': str(pos_size),
            'slTriggerPx': str(stop_loss),
            'slOrdPx': '-1',  # Market order when triggered
            'reduceOnly': 'true'
        }
        
        return self._request('POST', endpoint, data=data)
    
    def set_trailing_stop(self, symbol: str, callback_ratio: float, position_side: str = None) -> Dict:
        """
        Set trailing stop for a position
        
        Args:
            symbol: Symbol to set trailing stop for
            callback_ratio: Callback ratio for trailing stop (e.g., 0.05 for 5%)
            position_side: Position side (long, short)
            
        Returns:
            Response data
        """
        endpoint = "/api/v5/trade/order"
        
        # Determine the side for the trailing stop order
        ts_side = 'sell' if position_side == 'long' else 'buy'
        
        # Get position size
        positions = self.get_positions(symbol)
        position = None
        for pos in positions:
            if pos['instId'] == symbol:
                position = pos
                break
        
        if not position or float(position['pos']) == 0:
            logger.info(f"No position to set trailing stop for {symbol}")
            return {'success': False, 'message': f"No position to set trailing stop for {symbol}"}
        
        pos_size = abs(float(position['pos']))
        
        # Create trailing stop order
        data = {
            'instId': symbol,
            'tdMode': 'cross',
            'side': ts_side,
            'ordType': 'move_order_stop',
            'sz': str(pos_size),
            'callbackRatio': str(callback_ratio),
            'reduceOnly': 'true'
        }
        
        return self._request('POST', endpoint, data=data)
