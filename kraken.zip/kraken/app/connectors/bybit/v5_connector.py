import os
import time
import logging
import hmac
import hashlib
import json
from typing import Dict, List, Optional, Union, Any
import requests
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

class BybitV5Connector:
    """
    Connector for Bybit V5 API
    """
    def __init__(self, api_key: str = None, api_secret: str = None, testnet: bool = False):
        """
        Initialize the Bybit V5 connector
        
        Args:
            api_key: API key for authentication
            api_secret: API secret for authentication
            testnet: Whether to use testnet
        """
        self.api_key = api_key or os.environ.get('BYBIT_API_KEY')
        self.api_secret = api_secret or os.environ.get('BYBIT_API_SECRET')
        
        if not self.api_key or not self.api_secret:
            raise ValueError("API key and secret are required for Bybit V5 connector")
        
        self.base_url = "https://api-testnet.bybit.com" if testnet else "https://api.bybit.com"
        self.recv_window = 5000
        self.session = requests.Session()
        self.session.headers.update({
            'X-BAPI-API-KEY': self.api_key,
            'Content-Type': 'application/json'
        })
        
        # Rate limiting
        self.request_count = 0
        self.request_limit = 50  # Requests per minute
        self.last_request_time = time.time()
        
    def _generate_signature(self, params: Dict) -> str:
        """
        Generate signature for authentication
        
        Args:
            params: Parameters for the request
            
        Returns:
            Signature string
        """
        timestamp = int(time.time() * 1000)
        params['timestamp'] = timestamp
        params['recv_window'] = self.recv_window
        
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        return signature
    
    def _handle_rate_limit(self):
        """
        Handle rate limiting
        """
        current_time = time.time()
        elapsed = current_time - self.last_request_time
        
        if elapsed >= 60:
            # Reset counter after 1 minute
            self.request_count = 0
            self.last_request_time = current_time
        elif self.request_count >= self.request_limit:
            # Sleep if we've hit the limit
            sleep_time = 60 - elapsed
            logger.info(f"Rate limit reached, sleeping for {sleep_time:.2f} seconds")
            time.sleep(sleep_time)
            self.request_count = 0
            self.last_request_time = time.time()
            
        self.request_count += 1
    
    def _request(self, method: str, endpoint: str, params: Dict = None, signed: bool = True) -> Dict:
        """
        Make a request to the Bybit API
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint
            params: Request parameters
            signed: Whether the request needs to be signed
            
        Returns:
            Response data
        """
        self._handle_rate_limit()
        
        url = f"{self.base_url}{endpoint}"
        params = params or {}
        
        if signed:
            signature = self._generate_signature(params)
            self.session.headers.update({'X-BAPI-SIGN': signature})
        
        try:
            if method == 'GET':
                response = self.session.get(url, params=params)
            elif method == 'POST':
                response = self.session.post(url, json=params)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            data = response.json()
            
            if data['retCode'] != 0:
                logger.error(f"API error: {data['retMsg']}")
                raise Exception(f"Bybit API error: {data['retMsg']}")
            
            return data['result']
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error in request: {str(e)}")
            raise
    
    def get_account_info(self) -> Dict:
        """
        Get account information
        
        Returns:
            Account information
        """
        endpoint = "/v5/account/wallet-balance"
        params = {'accountType': 'UNIFIED'}
        return self._request('GET', endpoint, params)
    
    def get_positions(self, symbol: Optional[str] = None) -> List[Dict]:
        """
        Get positions
        
        Args:
            symbol: Symbol to get positions for
            
        Returns:
            List of positions
        """
        endpoint = "/v5/position/list"
        params = {}
        if symbol:
            params['symbol'] = symbol
        
        return self._request('GET', endpoint, params)
    
    def fetch_ohlcv(self, symbol: str, timeframe: str = '1h', limit: int = 100) -> List[Dict]:
        """
        Fetch OHLCV data
        
        Args:
            symbol: Symbol to fetch data for
            timeframe: Timeframe (1m, 5m, 15m, 30m, 1h, 4h, 1d)
            limit: Number of candles to fetch
            
        Returns:
            List of OHLCV data
        """
        endpoint = "/v5/market/kline"
        params = {
            'symbol': symbol,
            'interval': timeframe,
            'limit': limit
        }
        
        return self._request('GET', endpoint, params, signed=False)
    
    def fetch_order_book(self, symbol: str, limit: int = 50) -> Dict:
        """
        Fetch order book
        
        Args:
            symbol: Symbol to fetch order book for
            limit: Depth of the order book
            
        Returns:
            Order book data
        """
        endpoint = "/v5/market/orderbook"
        params = {
            'symbol': symbol,
            'limit': limit
        }
        
        return self._request('GET', endpoint, params, signed=False)
    
    def create_order(self, symbol: str, side: str, order_type: str, quantity: float,
                    price: Optional[float] = None, time_in_force: str = 'GTC',
                    reduce_only: bool = False, close_on_trigger: bool = False) -> Dict:
        """
        Create an order
        
        Args:
            symbol: Symbol to create order for
            side: Order side (Buy, Sell)
            order_type: Order type (Market, Limit)
            quantity: Order quantity
            price: Order price (required for Limit orders)
            time_in_force: Time in force (GTC, IOC, FOK)
            reduce_only: Whether the order is reduce-only
            close_on_trigger: Whether to close position on trigger
            
        Returns:
            Order information
        """
        endpoint = "/v5/order/create"
        params = {
            'symbol': symbol,
            'side': side,
            'orderType': order_type,
            'qty': str(quantity),
            'timeInForce': time_in_force,
            'reduceOnly': reduce_only,
            'closeOnTrigger': close_on_trigger
        }
        
        if order_type == 'Limit' and price is not None:
            params['price'] = str(price)
        
        return self._request('POST', endpoint, params)
    
    def modify_order(self, symbol: str, order_id: str, price: Optional[float] = None,
                    quantity: Optional[float] = None) -> Dict:
        """
        Modify an order
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to modify
            price: New price
            quantity: New quantity
            
        Returns:
            Modified order information
        """
        endpoint = "/v5/order/amend"
        params = {
            'symbol': symbol,
            'orderId': order_id
        }
        
        if price is not None:
            params['price'] = str(price)
        
        if quantity is not None:
            params['qty'] = str(quantity)
        
        return self._request('POST', endpoint, params)
    
    def cancel_order(self, symbol: str, order_id: str) -> Dict:
        """
        Cancel an order
        
        Args:
            symbol: Symbol of the order
            order_id: Order ID to cancel
            
        Returns:
            Cancelled order information
        """
        endpoint = "/v5/order/cancel"
        params = {
            'symbol': symbol,
            'orderId': order_id
        }
        
        return self._request('POST', endpoint, params)
    
    def close_position(self, symbol: str) -> Dict:
        """
        Close a position
        
        Args:
            symbol: Symbol of the position to close
            
        Returns:
            Closed position information
        """
        # Get current position
        position = self.get_positions(symbol)
        if not position or not position['list']:
            logger.info(f"No position to close for {symbol}")
            return {'success': True, 'message': f"No position to close for {symbol}"}
        
        # Get position size and side
        pos_size = float(position['list'][0]['size'])
        pos_side = position['list'][0]['side']
        
        if pos_size == 0:
            logger.info(f"No position to close for {symbol}")
            return {'success': True, 'message': f"No position to close for {symbol}"}
        
        # Create market order to close position
        close_side = 'Sell' if pos_side == 'Buy' else 'Buy'
        
        return self.create_order(
            symbol=symbol,
            side=close_side,
            order_type='Market',
            quantity=pos_size,
            reduce_only=True
        )
    
    def set_leverage(self, symbol: str, leverage: int) -> Dict:
        """
        Set leverage for a symbol
        
        Args:
            symbol: Symbol to set leverage for
            leverage: Leverage value
            
        Returns:
            Response data
        """
        endpoint = "/v5/position/set-leverage"
        params = {
            'symbol': symbol,
            'buyLeverage': str(leverage),
            'sellLeverage': str(leverage)
        }
        
        return self._request('POST', endpoint, params)
    
    def set_stop_loss(self, symbol: str, stop_loss: float, position_side: str = None) -> Dict:
        """
        Set stop loss for a position
        
        Args:
            symbol: Symbol to set stop loss for
            stop_loss: Stop loss price
            position_side: Position side (Buy, Sell)
            
        Returns:
            Response data
        """
        endpoint = "/v5/position/trading-stop"
        params = {
            'symbol': symbol,
            'stopLoss': str(stop_loss)
        }
        
        if position_side:
            params['positionIdx'] = 1 if position_side == 'Buy' else 2
        
        return self._request('POST', endpoint, params)
    
    def set_trailing_stop(self, symbol: str, trailing_stop: float, position_side: str = None) -> Dict:
        """
        Set trailing stop for a position
        
        Args:
            symbol: Symbol to set trailing stop for
            trailing_stop: Trailing stop value
            position_side: Position side (Buy, Sell)
            
        Returns:
            Response data
        """
        endpoint = "/v5/position/trading-stop"
        params = {
            'symbol': symbol,
            'trailingStop': str(trailing_stop)
        }
        
        if position_side:
            params['positionIdx'] = 1 if position_side == 'Buy' else 2
        
        return self._request('POST', endpoint, params)
