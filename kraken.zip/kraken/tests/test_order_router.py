import unittest
from unittest.mock import MagicMock, patch
import sys
import os
import logging

# Add the project root to the path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.core.order_router import OrderRouter, ExchangeStatus, ExchangeInfo

# Configure logging
logging.basicConfig(level=logging.INFO)


class TestOrderRouter(unittest.TestCase):
    """Test cases for the OrderRouter class"""

    @patch('app.connectors.connector_factory.ConnectorFactory.create_connector')
    def setUp(self, mock_create_connector):
        """Set up test fixtures"""
        # Create mock connectors
        self.bybit_mock = MagicMock()
        self.okx_mock = MagicMock()
        self.binance_mock = MagicMock()
        
        # Configure the mock to return our mock connectors
        mock_create_connector.side_effect = lambda exchange, **kwargs: {
            'bybit': self.bybit_mock,
            'okx': self.okx_mock,
            'binance': self.binance_mock
        }[exchange]
        
        # Configure exchanges
        self.exchanges_config = [
            {'name': 'bybit', 'api_key': 'test', 'api_secret': 'test', 'priority': 0},
            {'name': 'okx', 'api_key': 'test', 'api_secret': 'test', 'passphrase': 'test', 'priority': 1},
            {'name': 'binance', 'api_key': 'test', 'api_secret': 'test', 'priority': 2}
        ]
        
        # Initialize the router with mocked health check
        with patch.object(OrderRouter, 'start_health_check'):
            self.router = OrderRouter(self.exchanges_config)
            
        # Manually set exchanges as healthy for testing
        for exchange in self.router.exchanges:
            exchange.mark_healthy()
        
        # Set active exchange to bybit (highest priority)
        self.router.active_exchange = self.router.exchanges[0]

    def test_initialization(self):
        """Test that the router initializes correctly"""
        self.assertEqual(len(self.router.exchanges), 3)
        self.assertEqual(self.router.exchanges[0].name, 'bybit')
        self.assertEqual(self.router.exchanges[1].name, 'okx')
        self.assertEqual(self.router.exchanges[2].name, 'binance')
        
        # Check priorities
        self.assertEqual(self.router.exchanges[0].priority, 0)
        self.assertEqual(self.router.exchanges[1].priority, 1)
        self.assertEqual(self.router.exchanges[2].priority, 2)
        
        # Check active exchange
        self.assertEqual(self.router.active_exchange.name, 'bybit')

    def test_failover_logic(self):
        """Test failover logic when primary exchange fails"""
        # Configure bybit to fail
        self.bybit_mock.get_account_info.side_effect = Exception("Connection error")
        
        # Configure okx to succeed
        self.okx_mock.get_account_info.return_value = {'balance': 1000}
        
        # Call method that should trigger failover
        result = self.router.get_account_info()
        
        # Verify that bybit was tried first
        self.bybit_mock.get_account_info.assert_called_once()
        
        # Verify that okx was used as failover
        self.okx_mock.get_account_info.assert_called_once()
        
        # Verify the result came from okx
        self.assertEqual(result, {'balance': 1000})
        
        # Verify that active exchange was updated
        self.assertEqual(self.router.active_exchange.name, 'okx')

    def test_all_exchanges_fail(self):
        """Test behavior when all exchanges fail"""
        # Configure all exchanges to fail
        self.bybit_mock.get_account_info.side_effect = Exception("Bybit error")
        self.okx_mock.get_account_info.side_effect = Exception("OKX error")
        self.binance_mock.get_account_info.side_effect = Exception("Binance error")
        
        # Call method and expect exception
        with self.assertRaises(Exception) as context:
            self.router.get_account_info()
        
        # Verify error message
        self.assertTrue("All exchanges failed" in str(context.exception))
        
        # Verify all exchanges were tried
        self.bybit_mock.get_account_info.assert_called_once()
        self.okx_mock.get_account_info.assert_called_once()
        self.binance_mock.get_account_info.assert_called_once()

    def test_create_order(self):
        """Test create order with successful execution"""
        # Configure bybit to succeed
        self.bybit_mock.create_order.return_value = {'orderId': '12345'}
        
        # Call create_order
        result = self.router.create_order(
            symbol='BTCUSDT',
            side='Buy',
            order_type='Limit',
            quantity=1.0,
            price=50000.0
        )
        
        # Verify bybit was called with correct parameters
        self.bybit_mock.create_order.assert_called_once_with(
            symbol='BTCUSDT',
            side='Buy',
            order_type='Limit',
            quantity=1.0,
            price=50000.0,
            time_in_force='GTC',
            reduce_only=False,
            close_on_trigger=False
        )
        
        # Verify result
        self.assertEqual(result, {'orderId': '12345'})

    def test_exchange_status_tracking(self):
        """Test exchange status tracking"""
        # Get initial status
        status = self.router.get_exchange_status()
        self.assertEqual(status['bybit'], 'healthy')
        self.assertEqual(status['okx'], 'healthy')
        self.assertEqual(status['binance'], 'healthy')
        
        # Mark bybit as unhealthy
        self.router.exchanges[0].mark_unhealthy("Test failure")
        
        # Get updated status
        status = self.router.get_exchange_status()
        self.assertEqual(status['bybit'], 'unhealthy')
        self.assertEqual(status['okx'], 'healthy')
        self.assertEqual(status['binance'], 'healthy')


if __name__ == '__main__':
    unittest.main()
