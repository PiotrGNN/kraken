import os
import logging
import argparse
from dotenv import load_dotenv
from app.connectors import ConnectorFactory

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """
    Main entry point for the DeepAgent Kraken trading bot
    """
    # Load environment variables from .env file
    load_dotenv()
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='DeepAgent Kraken Trading Bot')
    parser.add_argument('--exchange', type=str, default='bybit', choices=['bybit', 'okx', 'binance'],
                        help='Exchange to use (bybit, okx, binance)')
    parser.add_argument('--testnet', action='store_true', help='Use testnet')
    args = parser.parse_args()
    
    try:
        # Create connector for the specified exchange
        logger.info(f"Creating connector for {args.exchange}")
        
        if args.exchange == 'okx':
            connector = ConnectorFactory.create_connector(
                exchange=args.exchange,
                api_key=os.environ.get(f'{args.exchange.upper()}_API_KEY'),
                api_secret=os.environ.get(f'{args.exchange.upper()}_API_SECRET'),
                passphrase=os.environ.get(f'{args.exchange.upper()}_PASSPHRASE'),
                testnet=args.testnet
            )
        else:
            connector = ConnectorFactory.create_connector(
                exchange=args.exchange,
                api_key=os.environ.get(f'{args.exchange.upper()}_API_KEY'),
                api_secret=os.environ.get(f'{args.exchange.upper()}_API_SECRET'),
                testnet=args.testnet
            )
        
        # Get account information
        account_info = connector.get_account_info()
        logger.info(f"Account info: {account_info}")
        
        # Get positions
        positions = connector.get_positions()
        logger.info(f"Positions: {positions}")
        
        # Example: Fetch OHLCV data for BTC/USDT
        symbol = 'BTC/USDT'
        ohlcv = connector.fetch_ohlcv(symbol, timeframe='1h', limit=10)
        logger.info(f"OHLCV data for {symbol}: {ohlcv[:2]}...")
        
        # Example: Fetch order book for BTC/USDT
        order_book = connector.fetch_order_book(symbol, limit=5)
        logger.info(f"Order book for {symbol}: {order_book}")
        
        # Note: Uncomment the following lines to test order creation and position management
        # (Make sure you have proper risk management in place before running these)
        
        # # Example: Create a limit order
        # order = connector.create_order(
        #     symbol=symbol,
        #     side='Buy',
        #     order_type='Limit',
        #     quantity=0.001,
        #     price=25000.0,
        #     reduce_only=False
        # )
        # logger.info(f"Created order: {order}")
        
        # # Example: Set leverage
        # leverage = connector.set_leverage(symbol, 5)
        # logger.info(f"Set leverage: {leverage}")
        
        # # Example: Set stop loss
        # stop_loss = connector.set_stop_loss(symbol, 24000.0, 'Buy')
        # logger.info(f"Set stop loss: {stop_loss}")
        
        # # Example: Set trailing stop
        # trailing_stop = connector.set_trailing_stop(symbol, 0.05, 'Buy')
        # logger.info(f"Set trailing stop: {trailing_stop}")
        
        # # Example: Close position
        # close_position = connector.close_position(symbol)
        # logger.info(f"Closed position: {close_position}")
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
