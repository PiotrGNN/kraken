import os
import sys
import logging
import time
from typing import Dict, List

# Add the project root to the path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app.core.order_router import OrderRouter
from app.connectors.connector_factory import ConnectorFactory

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """
    Example script demonstrating the use of the OrderRouter
    """
    # Load API keys from environment variables
    bybit_api_key = os.environ.get('BYBIT_API_KEY')
    bybit_api_secret = os.environ.get('BYBIT_API_SECRET')
    okx_api_key = os.environ.get('OKX_API_KEY')
    okx_api_secret = os.environ.get('OKX_API_SECRET')
    okx_passphrase = os.environ.get('OKX_PASSPHRASE')
    binance_api_key = os.environ.get('BINANCE_API_KEY')
    binance_api_secret = os.environ.get('BINANCE_API_SECRET')
    
    # Check if API keys are available
    if not all([bybit_api_key, bybit_api_secret]):
        logger.warning("Bybit API keys not found in environment variables")
    
    if not all([okx_api_key, okx_api_secret, okx_passphrase]):
        logger.warning("OKX API keys not found in environment variables")
    
    if not all([binance_api_key, binance_api_secret]):
        logger.warning("Binance API keys not found in environment variables")
    
    # Configure exchanges
    exchanges_config = [
        {
            'name': 'bybit',
            'api_key': bybit_api_key,
            'api_secret': bybit_api_secret,
            'testnet': True,  # Use testnet for safety
            'priority': 0  # Primary exchange
        },
        {
            'name': 'okx',
            'api_key': okx_api_key,
            'api_secret': okx_api_secret,
            'passphrase': okx_passphrase,
            'testnet': True,
            'priority': 1  # First failover
        },
        {
            'name': 'binance',
            'api_key': binance_api_key,
            'api_secret': binance_api_secret,
            'testnet': True,
            'priority': 2  # Second failover
        }
    ]
    
    try:
        # Initialize the OrderRouter
        logger.info("Initializing OrderRouter...")
        router = OrderRouter.initialize(exchanges_config)
        
        # Wait for health checks to complete
        logger.info("Waiting for health checks to complete...")
        time.sleep(5)
        
        # Get exchange status
        status = router.get_exchange_status()
        logger.info(f"Exchange status: {status}")
        
        # Get active exchange
        active_exchange = router.get_active_exchange()
        logger.info(f"Active exchange: {active_exchange.name}")
        
        # Example: Get account information
        try:
            logger.info("Getting account information...")
            account_info = router.get_account_info()
            logger.info(f"Account info: {account_info}")
        except Exception as e:
            logger.error(f"Error getting account info: {str(e)}")
        
        # Example: Get market data
        try:
            symbol = "BTCUSDT"
            logger.info(f"Fetching OHLCV data for {symbol}...")
            ohlcv = router.fetch_ohlcv(symbol, timeframe="1h", limit=5)
            logger.info(f"OHLCV data: {ohlcv}")
        except Exception as e:
            logger.error(f"Error fetching OHLCV data: {str(e)}")
        
        # Example: Place a limit order (commented out for safety)
        """
        try:
            logger.info("Placing a limit order...")
            order = router.create_order(
                symbol="BTCUSDT",
                side="Buy",
                order_type="Limit",
                quantity=0.001,  # Small quantity for testing
                price=20000.0,   # Price far from market for safety
                reduce_only=False
            )
            logger.info(f"Order placed: {order}")
            
            # Cancel the order
            if 'orderId' in order:
                logger.info(f"Cancelling order {order['orderId']}...")
                cancel_result = router.cancel_order("BTCUSDT", order['orderId'])
                logger.info(f"Cancel result: {cancel_result}")
        except Exception as e:
            logger.error(f"Error with order operations: {str(e)}")
        """
        
        # Example: Simulate failover
        logger.info("Simulating failover by marking primary exchange as unhealthy...")
        router.exchanges[0].mark_unhealthy("Simulated failure")
        
        # Wait for failover to occur
        time.sleep(2)
        
        # Get updated active exchange
        active_exchange = router.get_active_exchange()
        logger.info(f"New active exchange after failover: {active_exchange.name}")
        
        # Example: Get positions with failover
        try:
            logger.info("Getting positions (should use failover exchange)...")
            positions = router.get_positions()
            logger.info(f"Positions: {positions}")
        except Exception as e:
            logger.error(f"Error getting positions: {str(e)}")
        
    except Exception as e:
        logger.error(f"Error in example script: {str(e)}")
    finally:
        # Clean up
        if 'router' in locals():
            router.stop_health_check()
        logger.info("Example completed")


if __name__ == "__main__":
    main()
