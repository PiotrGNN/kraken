# DeepAgent Kraken Trading Bot

A robust trading bot with multiple exchange connectors for failover capability.

## Features

- Multi-exchange support (Bybit, OKX, Binance)
- Trend-following strategy with RSI counter
- Risk management with ATR-based position sizing and trailing stops
- Failover capability between exchanges

## Exchange Connectors

The bot supports the following exchanges:

1. **Bybit V5** - Primary exchange connector
2. **OKX** - Secondary exchange connector
3. **Binance** - Tertiary exchange connector for additional failover

## Trading Strategy

The bot implements a trend-following strategy with RSI counter:

- SMA-50 / SMA-200 cross determines direction
- Long position only when SMA50 > SMA200 and RSI-14 < 65
- Short position (on perpetual) when SMA50 < SMA200 and RSI-14 > 35

## Risk Management

1. Position sizing = equity × 1% / (ATR14 × 1.5)
2. Stop-Loss = 1.5 × ATR (server-side)
3. Trailing-stop = move to breakeven after +1 ATR, then step by 0.5 ATR

## Setup

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Set up environment variables for API keys
4. Run the bot: `python main.py`

## Environment Variables

```
# Bybit API Keys
BYBIT_API_KEY=your_bybit_api_key
BYBIT_API_SECRET=your_bybit_api_secret

# OKX API Keys
OKX_API_KEY=your_okx_api_key
OKX_API_SECRET=your_okx_api_secret
OKX_PASSPHRASE=your_okx_passphrase

# Binance API Keys
BINANCE_API_KEY=your_binance_api_key
BINANCE_API_SECRET=your_binance_api_secret
```

## License

MIT
